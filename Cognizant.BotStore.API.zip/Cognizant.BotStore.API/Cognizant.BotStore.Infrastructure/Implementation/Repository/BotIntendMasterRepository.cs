﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using EFCore.BulkExtensions;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotIntendMasterRepository : IBotIntendMasterRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotIntendMasterRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task DeleteBotIntendMaster(List<BotIntendMaster> botIntendMaster)
        {
            try
            {
                await _dbContext.BulkDeleteAsync(botIntendMaster);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotIntendMaster>> GetBotIntendMaster()
        {
            try
            {
                return await _dbContext.BotIntendMaster.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotIntendMaster>> GetBotIntendMasterById(int botId)
        {
            return await _dbContext.BotIntendMaster.AsNoTracking().Where(x => x.BotMasterID == botId).ToListAsync();
        }

        public async Task<int> SaveBotIntendMaster(BotIntendMaster botIntendMaster)
        {
            try
            {
                var existsRelease = await _dbContext.BotIntendMaster.AsNoTracking().FirstOrDefaultAsync(x => x.BotIntendMasterID == botIntendMaster.BotIntendMasterID);
                if (existsRelease == null)
                {
                    _dbContext.BotIntendMaster.Add(botIntendMaster);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.BotIntendMaster.UpdateRange(botIntendMaster);
                    await _dbContext.SaveChangesAsync();
                }
                return botIntendMaster.BotIntendMasterID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteBotIntendMasterById(int botIntendMasterId)
        {
            try
            {
                var result = _dbContext.BotIntendMaster.Where(x => x.BotIntendMasterID == botIntendMasterId).FirstOrDefault<BotIntendMaster>();
                if (result != null)
                {
                    _dbContext.BotIntendMaster.Remove(result);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
