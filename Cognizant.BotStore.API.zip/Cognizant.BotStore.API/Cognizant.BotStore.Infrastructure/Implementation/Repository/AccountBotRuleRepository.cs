using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;
using EFCore.BulkExtensions;

namespace Cognizant.BotStore.Infrastructure
{
    public class AccountBotRuleRepository : IAccountBotRuleRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public AccountBotRuleRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteAccountBotRuleById(int accountbotruleId)
        {
            try
            {
                var accountbotrule = _dbContext.AccountBotRule.Where(s => s.AccountBotRuleID == accountbotruleId).FirstOrDefault();
                if (accountbotrule != null)
                {
                    _dbContext.AccountBotRule.Remove(accountbotrule);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.NotExistsCode,
                        StatusDescription = string.Format(CommonVariable.NotExistsMessage, accountbotruleId)
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete AccountBotRuleById()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<BaseResponse> DeleteRuleByAccountBotID(int accountID, int botID)
        {
            try
            {
                var accountbotrule = _dbContext.AccountBotRule.Where(s => s.AccountID == accountID && s.BotMasterID == botID).ToList();
                if (accountbotrule != null)
                {
                    _dbContext.AccountBotRule.RemoveRange(accountbotrule);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.NotExistsCode,
                        StatusDescription = string.Format(CommonVariable.NotExistsMessage, botID)
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete AccountBotRuleById()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<AccountBotRule> GetAccountBotRuleById(int accountbotruleId)
        {
            try
            {
                return await _dbContext.AccountBotRule.AsNoTracking().Where(x => x.AccountBotRuleID == accountbotruleId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<AccountBotRule>> GetAccountBotRule()
        {
            try
            {
                return await _dbContext.AccountBotRule.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> BulkSaveAccountBotRule(IList<AccountBotRule> accountbotrule)
        {
            try
            {
                await _dbContext.BulkInsertOrUpdateAsync(accountbotrule);
                return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in BulkSaveAccountBotRule()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> SaveAccountBotRule(AccountBotRule accountBotRule)
        {
            try
            {
                var existsAccountBotRule = await _dbContext.AccountBotRule.AsNoTracking().
                                                                 FirstOrDefaultAsync(x => x.AccountID == accountBotRule.AccountID
                                                                                && x.BotMasterID == accountBotRule.BotMasterID && x.RuleMasterID == accountBotRule.RuleMasterID);

                if (existsAccountBotRule == null)
                {
                    _dbContext.AccountBotRule.Add(accountBotRule);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = accountBotRule.AccountBotRuleID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, accountBotRule.RuleMasterID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveAccountBotRule()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateAccountBotRule(AccountBotRule accountbotrule)
        {
            try
            {
                var existsAccountBotRule = await _dbContext.AccountBotRule.AsNoTracking().FirstOrDefaultAsync(x => x.AccountBotRuleID == accountbotrule.AccountBotRuleID);
                if (existsAccountBotRule != null)
                {
                    if (existsAccountBotRule.AccountID == accountbotrule.AccountID
                        && existsAccountBotRule.BotMasterID == accountbotrule.BotMasterID
                        && existsAccountBotRule.RuleMasterID == accountbotrule.RuleMasterID
                        )
                    {
                        return new BaseResponse
                        {
                            StatusCode = CommonVariable.AlreadyExistsCode,
                            StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, accountbotrule.RuleMasterID)
                        };
                    }
                    else
                    {
                        _dbContext.AccountBotRule.UpdateRange(accountbotrule);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, accountbotrule.AccountBotRuleID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateAccountBotRule()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }

        public async Task<BaseResponse> DeleteAccountBotRule(List<AccountBotRule> accountBotRules)
        {
            try
            {
                await _dbContext.BulkDeleteAsync(accountBotRules);
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in DeleteAccountBotRule()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

