using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class ConditionTypeValueRepository : IConditionTypeValueRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public ConditionTypeValueRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteConditionTypeValueById(int conditiontypevalueId)
        {
            try
            {
                var conditiontypevalue = _dbContext.ConditionTypeValue.Where(s => s.ConditionTypeValueID == conditiontypevalueId).FirstOrDefault<ConditionTypeValue>();
                if (conditiontypevalue != null)
                {
                    _dbContext.ConditionTypeValue.Remove(conditiontypevalue);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete ConditionTypeValueById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "ConditionTypeValueID -" + conditiontypevalueId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<ConditionTypeValue> GetConditionTypeValueById(int conditiontypevalueId)
        {
            try
            {
                return await _dbContext.ConditionTypeValue.AsNoTracking().Where(x => x.ConditionTypeValueID == conditiontypevalueId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<ConditionTypeValue>> GetConditionTypeValue()
        {
            try
            {
                return await _dbContext.ConditionTypeValue.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveConditionTypeValue(ConditionTypeValue conditiontypevalue)
        {
            try
            {
                var existsConditionTypeValue = await _dbContext.ConditionTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.Description == conditiontypevalue.Description);
                if (existsConditionTypeValue == null)
                {
                    _dbContext.ConditionTypeValue.Add(conditiontypevalue);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = conditiontypevalue.ConditionTypeValueID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, conditiontypevalue.Description) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveConditionTypeValue()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateConditionTypeValue(ConditionTypeValue conditiontypevalue)
        {
            try
            {
                var existsConditionTypeValue = await _dbContext.ConditionTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.ConditionTypeValueID == conditiontypevalue.ConditionTypeValueID);
                if (existsConditionTypeValue != null)
                {
                    if (existsConditionTypeValue.Description != conditiontypevalue.Description)
                    {
                        existsConditionTypeValue = await _dbContext.ConditionTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.Description == conditiontypevalue.Description);
                        if (existsConditionTypeValue != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, conditiontypevalue.Description)
                            };
                        }
                        else
                        {
                            _dbContext.ConditionTypeValue.UpdateRange(conditiontypevalue);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.ConditionTypeValue.UpdateRange(conditiontypevalue);
                        await _dbContext.SaveChangesAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateConditionTypeValue()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

