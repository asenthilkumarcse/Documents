using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class CategoryTypeRepository : ICategoryTypeRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public CategoryTypeRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteCategoryTypeById(int categorytypeId)
        {
            try
            {
                var categorytype = _dbContext.CategoryType.Where(s => s.CategoryTypeID == categorytypeId).FirstOrDefault<CategoryType>();
                if (categorytype != null)
                {
                    _dbContext.CategoryType.Remove(categorytype);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, categorytypeId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete CategoryTypeById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "CategoryTypeID -" + categorytypeId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<CategoryType> GetCategoryTypeById(int categorytypeId)
        {
            try
            {
                return await _dbContext.CategoryType.AsNoTracking().Where(x => x.CategoryTypeID == categorytypeId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<CategoryType>> GetCategoryType()
        {
            try
            {
                return await _dbContext.CategoryType.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveCategoryType(CategoryType categorytype)
        {
            try
            {
                var existsCategoryType = await _dbContext.CategoryType.AsNoTracking().FirstOrDefaultAsync(x => x.CategoryName == categorytype.CategoryName);
                if (existsCategoryType == null)
                {
                    _dbContext.CategoryType.Add(categorytype);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = categorytype.CategoryTypeID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, categorytype.CategoryName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveCategoryType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateCategoryType(CategoryType categorytype)
        {
            try
            {
                var existsCategoryType = await _dbContext.CategoryType.AsNoTracking().FirstOrDefaultAsync(x => x.CategoryTypeID == categorytype.CategoryTypeID);
                if (existsCategoryType != null)
                {
                    if (existsCategoryType.CategoryName != categorytype.CategoryName)
                    {
                        existsCategoryType = await _dbContext.CategoryType.AsNoTracking().FirstOrDefaultAsync(x => x.CategoryName == categorytype.CategoryName);
                        if (existsCategoryType != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, categorytype.CategoryName)
                            };
                        }
                        else
                        {
                            _dbContext.CategoryType.UpdateRange(categorytype);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.CategoryType.UpdateRange(categorytype);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, categorytype.CategoryTypeID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateCategoryType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

