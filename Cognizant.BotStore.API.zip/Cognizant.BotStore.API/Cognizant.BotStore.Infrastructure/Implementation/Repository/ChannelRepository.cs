using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class ChannelRepository : IChannelRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public ChannelRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteChannelById(int channelId)
        {
            try
            {
                var channel = _dbContext.Channel.Where(s => s.ChannelID == channelId).FirstOrDefault<Channel>();
                if (channel != null)
                {
                    _dbContext.Channel.Remove(channel);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, channelId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete ChannelById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "ChannelID -" + channelId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<Channel> GetChannelById(int channelId)
        {
            try
            {
                return await _dbContext.Channel.AsNoTracking().Where(x => x.ChannelID == channelId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<Channel>> GetChannel()
        {
            try
            {
                return await _dbContext.Channel.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveChannel(Channel channel)
        {
            try
            {
                var existsChannel = await _dbContext.Channel.AsNoTracking().FirstOrDefaultAsync(x => x.ChannelName == channel.ChannelName);
                if (existsChannel == null)
                {
                    _dbContext.Channel.Add(channel);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = channel.ChannelID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, channel.ChannelName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveChannel()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateChannel(Channel channel)
        {
            try
            {
                var existsChannel = await _dbContext.Channel.AsNoTracking().FirstOrDefaultAsync(x => x.ChannelID == channel.ChannelID);
                if (existsChannel != null)
                {
                    if (existsChannel.ChannelName != channel.ChannelName)
                    {
                        existsChannel = await _dbContext.Channel.AsNoTracking().FirstOrDefaultAsync(x => x.ChannelName == channel.ChannelName);
                        if (existsChannel != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, channel.ChannelName)
                            };
                        }
                        else
                        {
                            _dbContext.Channel.UpdateRange(channel);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.Channel.UpdateRange(channel);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, channel.ChannelID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateChannel()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

