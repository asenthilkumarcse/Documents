using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class ALMTypeRepository : IALMTypeRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public ALMTypeRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteALMTypeById(int almtypeId)
        {
            try
            {
                var almtype = _dbContext.ALMType.Where(s => s.ALMTypeID == almtypeId).FirstOrDefault<ALMType>();
                if (almtype != null)
                {
                    _dbContext.ALMType.Remove(almtype);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, almtypeId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete ALMTypeById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "ALMTypeID -" + almtypeId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<ALMType> GetALMTypeById(int almtypeId)
        {
            try
            {
                return await _dbContext.ALMType.AsNoTracking().Where(x => x.ALMTypeID == almtypeId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<ALMType>> GetALMType()
        {
            try
            {
                return await _dbContext.ALMType.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveALMType(ALMType almtype)
        {
            try
            {
                var existsALMType = await _dbContext.ALMType.AsNoTracking().FirstOrDefaultAsync(x => x.ALMName == almtype.ALMName);
                if (existsALMType == null)
                {
                    _dbContext.ALMType.Add(almtype);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = almtype.ALMTypeID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, almtype.ALMName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveALMType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateALMType(ALMType almtype)
        {
            try
            {
                var existsALMType = await _dbContext.ALMType.AsNoTracking().FirstOrDefaultAsync(x => x.ALMTypeID == almtype.ALMTypeID);
                if (existsALMType != null)
                {
                    if (existsALMType.ALMName != almtype.ALMName)
                    {
                        existsALMType = await _dbContext.ALMType.AsNoTracking().FirstOrDefaultAsync(x => x.ALMName == almtype.ALMName);
                        if (existsALMType != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, almtype.ALMName)
                            };
                        }
                        else
                        {
                            _dbContext.ALMType.UpdateRange(almtype);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.ALMType.UpdateRange(almtype);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, almtype.ALMTypeID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateALMType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

