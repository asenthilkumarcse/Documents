﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using EFCore.BulkExtensions;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotSkillMasterRepository : IBotSkillMasterRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotSkillMasterRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task DeleteBotSkillMaster(List<BotSkillMaster> botSkillMasters)
        {
            try
            {
                await _dbContext.BulkDeleteAsync(botSkillMasters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteBotSkillMasterById(int skillMasterID)
        {
            try
            {
                var result = _dbContext.BotSkillMaster.Where(x => x.BotSkillMasterID == skillMasterID).FirstOrDefault();
                if (result != null)
                {
                    _dbContext.BotSkillMaster.Remove(result);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotSkillMaster>> GetBotSkillMaster()
        {
            try
            {
                return await _dbContext.BotSkillMaster.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotSkillMaster>> GetBotSkillMasterById(int botId)
        {
            try
            {
                return await _dbContext.BotSkillMaster.AsNoTracking().Where(x => x.BotMasterID == botId).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveBotSkillMaster(BotSkillMaster botSkillMaster)
        {
            try
            {
                var existsRelease = await _dbContext.BotSkillMaster.AsNoTracking().FirstOrDefaultAsync(x => x.BotSkillMasterID == botSkillMaster.BotSkillMasterID);
                if (existsRelease == null)
                {
                    _dbContext.BotSkillMaster.Add(botSkillMaster);
                    await _dbContext.SaveChangesAsync();
                }
                return botSkillMaster.BotSkillMasterID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
