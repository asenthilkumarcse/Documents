﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class IntendDetailsRepository : IIntendDetailsRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public IntendDetailsRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<IntendDetail>> GetIntendDetails()
        {
            try
            {
                return await _dbContext.IntendDetail.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveIntendDetails(IntendDetail intendDetails)
        {
            try
            {
                var existsRelease = await _dbContext.IntendDetail.AsNoTracking().FirstOrDefaultAsync(x => x.IntendDetailID == intendDetails.IntendDetailID);
                if (existsRelease == null)
                {
                    _dbContext.IntendDetail.Add(intendDetails);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.IntendDetail.UpdateRange(intendDetails);
                    await _dbContext.SaveChangesAsync();
                }
                return intendDetails.IntendDetailID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteBotIntentDetailById(int intendDetailsId)
        {
            try
            {
                var result = _dbContext.IntendDetail.Where(x => x.IntendDetailID == intendDetailsId).FirstOrDefault<IntendDetail>();
                if (result != null)
                {
                    _dbContext.IntendDetail.Remove(result);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
