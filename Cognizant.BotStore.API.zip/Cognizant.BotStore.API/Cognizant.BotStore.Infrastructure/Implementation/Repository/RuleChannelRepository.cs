using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class RuleChannelRepository : IRuleChannelRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public RuleChannelRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteRuleChannelById(int rulechannelId)
        {
            try
            {
                if (rulechannelId >0)
                {
                    var rulechannel = _dbContext.RuleChannel.Where(s => s.RuleChannelID == rulechannelId).FirstOrDefault<RuleChannel>();
                    if (rulechannel != null)
                    {
                        _dbContext.RuleChannel.Remove(rulechannel);
                        await _dbContext.SaveChangesAsync();
                    }
                    else
                    {
                        return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, rulechannelId) };
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete RuleChannelById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "RuleChannelID -" + rulechannelId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<RuleChannel> GetRuleChannelById(int rulechannelId)
        {
            try
            {
                return await _dbContext.RuleChannel.AsNoTracking().Where(x => x.RuleChannelID == rulechannelId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<RuleChannel>> GetRuleChannel()
        {
            try
            {
                return await _dbContext.RuleChannel.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveRuleChannel(RuleChannel rulechannel)
        {
            try
            {
                var existsRuleChannel = await _dbContext.RuleChannel.AsNoTracking().
                        FirstOrDefaultAsync(x => x.RuleChannelID == rulechannel.ChannelID && x.RuleMasterID == rulechannel.RuleMasterID);
                if (existsRuleChannel == null)
                {
                    _dbContext.RuleChannel.Add(rulechannel);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = rulechannel.RuleChannelID };
                }
                else
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.AlreadyExistsCode,
                        StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, rulechannel.RuleMasterID)
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveRuleChannel()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateRuleChannel(RuleChannel rulechannel)
        {
            try
            {
                var existsRuleChannel = await _dbContext.RuleChannel.AsNoTracking().FirstOrDefaultAsync(x => x.RuleChannelID == rulechannel.RuleChannelID);
                if (existsRuleChannel != null)
                {
                    if (existsRuleChannel.ChannelID != rulechannel.ChannelID && existsRuleChannel.RuleMasterID == rulechannel.RuleMasterID)
                    {
                        existsRuleChannel = await _dbContext.RuleChannel.AsNoTracking().
                                FirstOrDefaultAsync(x => x.ChannelID == rulechannel.ChannelID && x.RuleMasterID == rulechannel.RuleMasterID);
                        if (existsRuleChannel != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, rulechannel.RuleMasterID + "," + rulechannel.RuleChannelID)
                            };
                        }
                        else
                        {
                            _dbContext.RuleChannel.UpdateRange(rulechannel);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.RuleChannel.UpdateRange(rulechannel);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.NotExistsCode,
                        StatusDescription = string.Format(CommonVariable.NotExistsMessage, rulechannel.RuleChannelID)
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateRuleChannel()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

