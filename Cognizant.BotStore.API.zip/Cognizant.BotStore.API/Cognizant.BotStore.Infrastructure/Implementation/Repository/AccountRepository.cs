
using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class AccountRepository : IAccountRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public AccountRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task DeleteAccountById(int accountId)
        {
            try
            {
                var account = _dbContext.Account.Where(s => s.AccountID == accountId).FirstOrDefault<Account>();
                if (account != null)
                {
                    _dbContext.Account.Remove(account);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<Account> GetAccountById(int accountId)
        {
            try
            {
                return await _dbContext.Account.AsNoTracking().Where(x => x.AccountID == accountId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<Account>> GetAccount()
        {
            try
            {
                return await _dbContext.Account.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveAccount(Account account)
        {
            try
            {
                var existsAccount = await _dbContext.Account.AsNoTracking().FirstOrDefaultAsync(x => x.AccountName == account.AccountName);
                if (existsAccount == null)
                {
                    _dbContext.Account.Add(account);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.Account.UpdateRange(account);
                    await _dbContext.SaveChangesAsync();
                }
                return account.AccountID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> UpdateAccount(Account account)
        {
            try
            {
                var existsAccount = await _dbContext.Account.AsNoTracking().FirstOrDefaultAsync(x => x.AccountID == account.AccountID);
                if (existsAccount == null)
                {
                    _dbContext.Account.Add(account);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.Account.UpdateRange(account);
                    await _dbContext.SaveChangesAsync();
                }
                return account.AccountID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

