using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class RuleTypeRepository : IRuleTypeRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public RuleTypeRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteRuleTypeById(int ruletypeId)
        {
            try
            {
                var ruletype = _dbContext.RuleType.Where(s => s.RuleTypeID == ruletypeId).FirstOrDefault<RuleType>();
                if (ruletype != null)
                {
                    _dbContext.RuleType.Remove(ruletype);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, ruletypeId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete RuleTypeById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "RuleTypeID -" + ruletypeId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<RuleType> GetRuleTypeById(int ruletypeId)
        {
            try
            {
                return await _dbContext.RuleType.AsNoTracking().Where(x => x.RuleTypeID == ruletypeId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<RuleType>> GetRuleType()
        {
            try
            {
                return await _dbContext.RuleType.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveRuleType(RuleType ruletype)
        {
            try
            {
                var existsRuleType = await _dbContext.RuleType.AsNoTracking().FirstOrDefaultAsync(x => x.RuleTypeName == ruletype.RuleTypeName);
                if (existsRuleType == null)
                {
                    _dbContext.RuleType.Add(ruletype);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = ruletype.RuleTypeID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, ruletype.RuleTypeName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveRuleType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateRuleType(RuleType ruletype)
        {
            try
            {
                var existsRuleType = await _dbContext.RuleType.AsNoTracking().FirstOrDefaultAsync(x => x.RuleTypeID == ruletype.RuleTypeID);
                if (existsRuleType != null)
                {
                    if (existsRuleType.RuleTypeName != ruletype.RuleTypeName)
                    {
                        existsRuleType = await _dbContext.RuleType.AsNoTracking().FirstOrDefaultAsync(x => x.RuleTypeName == ruletype.RuleTypeName);
                        if (existsRuleType != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, ruletype.RuleTypeName)
                            };
                        }
                        else
                        {
                            _dbContext.RuleType.UpdateRange(ruletype);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.RuleType.UpdateRange(ruletype);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, ruletype.RuleTypeID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateRuleType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

