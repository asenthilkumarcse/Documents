using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class ConditionTypeRepository : IConditionTypeRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public ConditionTypeRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteConditionTypeById(int conditiontypeId)
        {
            try
            {
                var conditiontype = _dbContext.ConditionType.Where(s => s.ConditionTypeID == conditiontypeId).FirstOrDefault<ConditionType>();
                if (conditiontype != null)
                {
                    _dbContext.ConditionType.Remove(conditiontype);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, conditiontypeId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete ConditionTypeById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "ConditionTypeID -" + conditiontypeId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<ConditionType> GetConditionTypeById(int conditiontypeId)
        {
            try
            {
                return await _dbContext.ConditionType.AsNoTracking().Where(x => x.ConditionTypeID == conditiontypeId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<ConditionType>> GetConditionType()
        {
            try
            {
                return await _dbContext.ConditionType.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveConditionType(ConditionType conditiontype)
        {
            try
            {
                var existsConditionType = await _dbContext.ConditionType.AsNoTracking().FirstOrDefaultAsync(x => x.ConditionTypeName == conditiontype.ConditionTypeName);
                if (existsConditionType == null)
                {
                    _dbContext.ConditionType.Add(conditiontype);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = conditiontype.ConditionTypeID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, conditiontype.ConditionTypeName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveConditionType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateConditionType(ConditionType conditiontype)
        {
            try
            {
                var existsConditionType = await _dbContext.ConditionType.AsNoTracking().FirstOrDefaultAsync(x => x.ConditionTypeID == conditiontype.ConditionTypeID);
                if (existsConditionType != null)
                {
                    if (existsConditionType.ConditionTypeName != conditiontype.ConditionTypeName)
                    {
                        existsConditionType = await _dbContext.ConditionType.AsNoTracking().FirstOrDefaultAsync(x => x.ConditionTypeName == conditiontype.ConditionTypeName);
                        if (existsConditionType != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, conditiontype.ConditionTypeName)
                            };
                        }
                        else
                        {
                            _dbContext.ConditionType.UpdateRange(conditiontype);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.ConditionType.UpdateRange(conditiontype);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, conditiontype.ConditionTypeID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateConditionType()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

