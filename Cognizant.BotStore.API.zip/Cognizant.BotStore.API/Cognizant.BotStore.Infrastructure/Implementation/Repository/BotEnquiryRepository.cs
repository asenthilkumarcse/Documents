using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotEnquiryRepository : IBotEnquiryRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotEnquiryRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteBotEnquiryById(int botenquiryId)
        {
            try
            {
                var botenquiry = _dbContext.BotEnquiry.Where(s => s.BotEnquiryID == botenquiryId).FirstOrDefault<BotEnquiry>();
                if (botenquiry != null)
                {
                    _dbContext.BotEnquiry.Remove(botenquiry);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, botenquiryId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete BotEnquiryById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "BotEnquiryID -" + botenquiryId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<BotEnquiry> GetBotEnquiryById(int botenquiryId)
        {
            try
            {
                return await _dbContext.BotEnquiry.AsNoTracking().Where(x => x.BotEnquiryID == botenquiryId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<BotEnquiry>> GetBotEnquiry()
        {
            try
            {
                return await _dbContext.BotEnquiry.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveBotEnquiry(BotEnquiry botenquiry)
        {
            try
            {
                //var existsBotEnquiry = await _dbContext.BotEnquiry.AsNoTracking().FirstOrDefaultAsync(x => x. == botenquiry.BotEnquiryName);
                //if (existsBotEnquiry == null)
                //{
                _dbContext.BotEnquiry.Add(botenquiry);
                await _dbContext.SaveChangesAsync();
                return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = botenquiry.BotEnquiryID };
                //}
                //else
                //{
                //    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, botenquiry.BotEnquiryName) };
                //}
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveBotEnquiry()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateBotEnquiry(BotEnquiry botenquiry)
        {
            try
            {
                var existsBotEnquiry = await _dbContext.BotEnquiry.AsNoTracking().FirstOrDefaultAsync(x => x.BotEnquiryID == botenquiry.BotEnquiryID);
                if (existsBotEnquiry != null)
                {
                    //if (existsBotEnquiry.BotEnquiryName != botenquiry.BotEnquiryName)
                    //{
                    //    existsBotEnquiry = await _dbContext.BotEnquiry.AsNoTracking().FirstOrDefaultAsync(x => x.BotEnquiryName == botenquiry.BotEnquiryName);
                    //    if (existsBotEnquiry != null)
                    //    {
                    //        return new BaseResponse
                    //        {
                    //            StatusCode = CommonVariable.AlreadyExistsCode,
                    //            StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, botenquiry.BotEnquiryName)
                    //        };
                    //    }
                    //    else
                    //    {
                    //        _dbContext.BotEnquiry.UpdateRange(botenquiry);
                    //        await _dbContext.SaveChangesAsync();
                    //    }
                    //}
                    //else
                    //{
                    _dbContext.BotEnquiry.UpdateRange(botenquiry);
                    await _dbContext.SaveChangesAsync();
                    //}
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, botenquiry.BotEnquiryID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateBotEnquiry()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

