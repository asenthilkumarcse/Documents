﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using EFCore.BulkExtensions;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotAttributeMasterRepository : IBotAttributeMasterRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotAttributeMasterRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task DeleteBotAttributeMaster(List<BotAttributeMaster> botAttributeMaster)
        {
            try
            {
                await _dbContext.BulkDeleteAsync(botAttributeMaster);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteBotAttributeMasterById(int botAttributeMasterId)
        {
            try
            {
                var result = _dbContext.BotAttributeMaster.Where(x => x.BotAttributeMasterID == botAttributeMasterId).FirstOrDefault<BotAttributeMaster>();
                if(result!=null)
                {
                    _dbContext.BotAttributeMaster.Remove(result);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotAttributeMaster>> GetBotAttributeMaster()
        {
            try
            {
                return await _dbContext.BotAttributeMaster.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<BotAttributeMaster>> GetBotAttributeMasterById(int botId)
        {
            try
            {
                return await _dbContext.BotAttributeMaster.AsNoTracking().Where(x => x.BotMasterID == botId).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveBotAttributeMaster(BotAttributeMaster botAttributeMaster)
        {
            try
            {
                var existsRelease = await _dbContext.BotAttributeMaster.AsNoTracking().FirstOrDefaultAsync(x => x.BotAttributeMasterID == botAttributeMaster.BotAttributeMasterID);
                if (existsRelease == null)
                {
                    _dbContext.BotAttributeMaster.Add(botAttributeMaster);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.BotAttributeMaster.UpdateRange(botAttributeMaster);
                    await _dbContext.SaveChangesAsync();
                }
                return botAttributeMaster.BotAttributeMasterID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
