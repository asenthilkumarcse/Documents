﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotAssignmentRepository : IBotAssignmentRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotAssignmentRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<BotAssignment>> GetBotAssignment()
        {
            try
            {
                return await _dbContext.BotAssignment.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<BotAssignment>> GetBotAssignmentByBotID(int botID)
        {
            try
            {
                return await _dbContext.BotAssignment
                                    .AsNoTracking()
                                    .Where(x => x.BotMasterID == botID)
                                    .Include(x => x.BotMaster)
                                    .Include(x => x.BotMaster.BotSkillMasters)
                                    .Include(x => x.BotMaster.BotAttributeMasters)
                                    .Include(x => x.BotMaster.BotIntendMasters)
                                    .Include(x => x.BotMaster.RuleMaster).ThenInclude(x => x.RuleType)
                                    .Include(x => x.BotMaster.RuleMaster).ThenInclude(x => x.RuleChannel).ThenInclude(x => x.Channel)
                                    .Include(x => x.AttributeDetails)
                                    .Include(x => x.IntendDetails)
                                    .Include(x => x.TeamDetail)
                                    .ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BotAssignment> GetBotAssignmentByTeam(int botID, int teamID)
        {
            try
            {
                //var result = await _dbContext.BotRuleMapping.AsNoTracking()
                //                 .Where(x => x.TeamDetailID == teamID)
                //                 .Include(x => x.BotAssignment)
                //                 .Include(x => x.RuleMaster)
                //                 .Include(x => x.TeamDetail)
                //                 .Include(x => x.BotAssignment.BotMaster)
                //                 .Include(x => x.BotAssignment.BotMaster.BotSkillMasters)
                //                 .Include(x => x.BotAssignment.BotMaster.BotAttributeMasters)
                //                 .Include(x => x.BotAssignment.BotMaster.BotIntendMasters)
                //                 .Include(x => x.BotAssignment.BotMaster.RuleMaster).ThenInclude(x => x.RuleType)
                //                 .Include(x => x.BotAssignment.BotMaster.RuleMaster).ThenInclude(x => x.RuleChannel).ThenInclude(x => x.Channel)
                //                 .Include(x => x.BotAssignment.AttributeDetails)
                //                 .Include(x => x.BotAssignment.IntendDetails)
                //                 .Include(x => x.BotAssignment.TeamDetail)
                //                 .ToListAsync();

                return await _dbContext.BotAssignment
                                    .AsNoTracking()
                                    .Where(x => x.BotMasterID == botID && x.TeamDetailID == teamID)
                                    .Include(x => x.BotMaster)
                                    .Include(x => x.BotMaster.BotSkillMasters)
                                    .Include(x => x.BotMaster.BotAttributeMasters)
                                    .Include(x => x.BotMaster.BotIntendMasters)
                                    .Include(x => x.BotMaster.RuleMaster).ThenInclude(x => x.RuleType)
                                    .Include(x => x.BotMaster.RuleMaster).ThenInclude(x => x.RuleChannel).ThenInclude(x => x.Channel)
                                    .Include(x => x.AttributeDetails)
                                    .Include(x => x.IntendDetails)
                                    .Include(x => x.TeamDetail)
                                    .FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveBotAssignment(BotAssignment botAssignment)
        {
            try
            {
                var existsRelease = await _dbContext.BotAssignment.AsNoTracking().FirstOrDefaultAsync(x => x.BotAssignmentID == botAssignment.BotAssignmentID);
                if (existsRelease == null)
                {
                    _dbContext.BotAssignment.Add(botAssignment);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    existsRelease.BotMasterID = botAssignment.BotMasterID;
                    existsRelease.Status = botAssignment.Status;
                    existsRelease.TeamDetailID = botAssignment.TeamDetailID;
                    existsRelease.BotMaster = botAssignment.BotMaster;
                    existsRelease.AttributeDetails = botAssignment.AttributeDetails;
                    existsRelease.IntendDetails = botAssignment.IntendDetails;
                    existsRelease.TeamDetail = botAssignment.TeamDetail;
                    _dbContext.BotAssignment.UpdateRange(botAssignment);
                    await _dbContext.SaveChangesAsync();
                }
                return botAssignment.BotAssignmentID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> DeletetBotAssignment(int botID, int teamID)
        {
            try
            {
                var assignbot = _dbContext.BotAssignment
                                    .AsNoTracking()
                                    .Where(x => x.BotMasterID == botID && x.TeamDetailID == teamID)
                                    .Include(x => x.BotMaster)
                                    .Include(x => x.BotMaster.BotSkillMasters)
                                    .Include(x => x.BotMaster.BotAttributeMasters)
                                    .Include(x => x.BotMaster.BotIntendMasters)
                                    .Include(x => x.AttributeDetails)
                                    .Include(x => x.IntendDetails)
                                    .Include(x => x.TeamDetail)
                                    .SingleOrDefault();
                if (assignbot != null)
                {
                    _dbContext.Remove(assignbot);
                    return await _dbContext.SaveChangesAsync();
                }
                return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
