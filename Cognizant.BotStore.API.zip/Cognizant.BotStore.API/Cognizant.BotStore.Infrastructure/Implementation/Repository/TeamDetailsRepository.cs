﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class TeamDetailsRepository : ITeamDetailsRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public TeamDetailsRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<TeamDetail>> GetTeamDetails()
        {
            try
            {
                return await _dbContext.TeamDetail.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<TeamDetail>> GetTeamDetailsByAccountID(int accountID)
        {
            try
            {
                return await _dbContext.TeamDetail.AsNoTracking().Where(x => x.AccountID == accountID).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveTeamDetails(TeamDetail teamDetails)
        {
            try
            {
                var existsRelease = await _dbContext.TeamDetail.AsNoTracking().FirstOrDefaultAsync(x => x.TeamName == teamDetails.TeamName);
                if (existsRelease == null)
                {
                    _dbContext.TeamDetail.Add(teamDetails);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    teamDetails.TeamName = existsRelease.TeamName;
                    _dbContext.TeamDetail.UpdateRange(teamDetails);
                    await _dbContext.SaveChangesAsync();
                }
                return teamDetails.TeamDetailID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task DeleteTeamDetailById(int teamDetailId)
        {
            try
            {
                var teamDetail = _dbContext.TeamDetail.Where(s => s.TeamDetailID == teamDetailId).FirstOrDefault<TeamDetail>();
                if (teamDetail != null)
                {
                    _dbContext.TeamDetail.Remove(teamDetail);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<TeamDetail> GetTeamDetailById(int teamDetailId)
        {
            try
            {
                return await _dbContext.TeamDetail.AsNoTracking().Where(x => x.TeamDetailID == teamDetailId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> UpdateTeamDetail(TeamDetail teamDetail)
        {
            try
            {
                var existsTeam = await _dbContext.TeamDetail.AsNoTracking().FirstOrDefaultAsync(x => x.TeamDetailID == teamDetail.TeamDetailID);
                if (existsTeam == null)
                {
                    _dbContext.TeamDetail.Add(existsTeam);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.TeamDetail.UpdateRange(teamDetail);
                    await _dbContext.SaveChangesAsync();
                }
                return teamDetail.TeamDetailID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<TeamDetail>> GetAssignedTeamDetailsByBotId(int botId)
        {
            try
            {
                var team = from td in _dbContext.TeamDetail
                           join ba in _dbContext.BotAssignment on td.TeamDetailID equals ba.TeamDetailID
                           where ba.BotMasterID == botId
                           select td;
                if (team != null && team.Count() > 0)
                    return await team.AsNoTracking().ToListAsync();
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<TeamDetail>> GetAssignedTeamDetailsByAccountID(int botId, int accountID)
        {
            try
            {
                var team = from td in _dbContext.TeamDetail
                           join ba in _dbContext.BotAssignment on td.TeamDetailID equals ba.TeamDetailID
                           where ba.BotMasterID == botId && td.AccountID == accountID
                           select td;
                if (team != null && team.Count() > 0)
                    return await team.AsNoTracking().ToListAsync();
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<TeamDetail>> GetUnAssignedTeamDetailsForBot(int botId)
        {
            try
            {
                var team = _dbContext.BotAssignment.Where(o => o.BotMasterID == botId).Select(o => o.TeamDetailID).ToList();
                if (team != null && team.Count > 0)
                    return await _dbContext.TeamDetail.Where(o => !team.Contains(o.TeamDetailID)).Select(o => o).ToListAsync();
                else
                    return await _dbContext.TeamDetail.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<TeamDetail>> GetUnAssignedTeamDetailsByAccountID(int botId, int accountID)
        {
            try
            {
                var team = _dbContext.BotAssignment.Where(o => o.BotMasterID == botId).Select(o => o.TeamDetailID).ToList();
                if (team != null && team.Count > 0)
                    return await _dbContext.TeamDetail.Where(o => !team.Contains(o.TeamDetailID) && o.AccountID == accountID).Select(o => o).ToListAsync();
                else
                    return await _dbContext.TeamDetail.AsNoTracking().Where(o=>o.AccountID == accountID).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
