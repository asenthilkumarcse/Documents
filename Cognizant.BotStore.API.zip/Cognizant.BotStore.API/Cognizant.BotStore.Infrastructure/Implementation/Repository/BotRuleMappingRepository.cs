using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotRuleMappingRepository : IBotRuleMappingRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotRuleMappingRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteBotRuleMappingById(int botrulemappingId)
        {
            try
            {
                var botrulemapping = _dbContext.BotRuleMapping.Where(s => s.BotRuleMappingID == botrulemappingId).FirstOrDefault<BotRuleMapping>();
                if (botrulemapping != null)
                {
                    _dbContext.BotRuleMapping.Remove(botrulemapping);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, botrulemappingId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete BotRuleMappingById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "BotRuleMappingID -" + botrulemappingId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<BotRuleMapping> GetBotRuleMappingById(int botrulemappingId)
        {
            try
            {
                return await _dbContext.BotRuleMapping.AsNoTracking().Where(x => x.BotRuleMappingID == botrulemappingId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<BotRuleMapping>> GetBotRuleMapping()
        {
            try
            {
                return await _dbContext.BotRuleMapping.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveBotRuleMapping(BotRuleMapping botrulemapping)
        {
            try
            {
                var existsBotRuleMapping = await _dbContext.BotRuleMapping.AsNoTracking().
                                                            FirstOrDefaultAsync(x => x.BotAssignmentID == botrulemapping.BotAssignmentID
                                                                        && x.BotRuleMappingID == botrulemapping.BotRuleMappingID);
                if (existsBotRuleMapping == null)
                {
                    _dbContext.BotRuleMapping.Add(botrulemapping);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = botrulemapping.BotRuleMappingID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, botrulemapping.BotAssignmentID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveBotRuleMapping()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateBotRuleMapping(BotRuleMapping botrulemapping)
        {
            try
            {
                var existsBotRuleMapping = await _dbContext.BotRuleMapping.AsNoTracking().FirstOrDefaultAsync(x => x.BotRuleMappingID == botrulemapping.BotRuleMappingID);
                if (existsBotRuleMapping != null)
                {
                    if (existsBotRuleMapping.BotAssignmentID != botrulemapping.BotAssignmentID
                        && existsBotRuleMapping.BotRuleMappingID != botrulemapping.BotRuleMappingID)
                    {
                        existsBotRuleMapping = await _dbContext.BotRuleMapping.AsNoTracking().
                                FirstOrDefaultAsync(x => x.BotAssignmentID == botrulemapping.BotAssignmentID && x.BotRuleMappingID == x.BotRuleMappingID);
                        if (existsBotRuleMapping != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, botrulemapping.BotAssignmentID)
                            };
                        }
                        else
                        {
                            _dbContext.BotRuleMapping.UpdateRange(botrulemapping);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.BotRuleMapping.UpdateRange(botrulemapping);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.NotExistsCode,
                        StatusDescription = string.Format(CommonVariable.NotExistsMessage, botrulemapping.BotRuleMappingID)
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateBotRuleMapping()");
                return new BaseResponse
                {
                    StatusCode = CommonVariable.InternalErrorCode,
                    StatusDescription = CommonVariable.InternalErrorMessage
                };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

