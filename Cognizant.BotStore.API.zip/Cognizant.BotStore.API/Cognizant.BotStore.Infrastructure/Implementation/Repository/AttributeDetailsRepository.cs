﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class AttributeDetailsRepository : IAttributeDetailsRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public AttributeDetailsRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<AttributeDetail>> GetAttributeDetails()
        {
            try
            {
                return await _dbContext.AttributeDetail.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveAttributeDetails(AttributeDetail attributeDetails)
        {
            try
            {
                var existsRelease = await _dbContext.AttributeDetail.AsNoTracking().FirstOrDefaultAsync(x => x.AttributeDetailID == attributeDetails.AttributeDetailID);
                if (existsRelease == null)
                {
                    _dbContext.AttributeDetail.Add(attributeDetails);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.AttributeDetail.UpdateRange(attributeDetails);
                    await _dbContext.SaveChangesAsync();
                }
                return attributeDetails.BotAssignmentID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteBotAttributeDetailsById(int attributeDetailsId)
        {
            try
            {
                var result = _dbContext.AttributeDetail.Where(x => x.AttributeDetailID == attributeDetailsId).FirstOrDefault<AttributeDetail>();
                if(result != null)
                {
                    _dbContext.AttributeDetail.Remove(result);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
