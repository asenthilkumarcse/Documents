﻿using Cognizant.BotStore.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Cognizant.BotStore.Infrastructure
{
    public class BotMasterRepository : IBotMasterRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotMasterRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<int> DeletetBotById(int botId)
        {
            try
            {
                var botMaster = _dbContext.BotMaster
                    .Where(i => i.BotMasterID == botId)
                    .Include(i => i.BotSkillMasters)
                    .Include(i => i.BotIntendMasters).ThenInclude(intend => intend.IntendDetails)
                    .Include(i => i.BotAttributeMasters).ThenInclude(att => att.AttributeDetails)
                    .Include(i => i.BotAssignments)
                    .Include(i => i.RuleMaster).ThenInclude(rule => rule.RuleChannel)
                    .SingleOrDefault();

                if (botMaster != null)
                {
                    _dbContext.Remove(botMaster);

                    return await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return 1;
        }

        public async Task<List<BotMaster>> GetBotMaster()
        {
            try
            {
                return await _dbContext.BotMaster
                    .Include(x => x.BotAttributeMasters)
                    .Include(x => x.BotIntendMasters)
                    .Include(x => x.BotSkillMasters)
                    .ToListAsync();

                //        var job = db.Jobs
                //.Include(x => x.Quotes.Select(q => q.QuoteItems))
                //.Where(x => x.JobID == id)
                //.SingleOrDefault();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<BotMaster> GetBotMasterById(int botId)
        {
            try
            {
                return await _dbContext.BotMaster
                                        .AsNoTracking()
                                        .Where(x => x.BotMasterID == botId)
                                        .Include(x => x.BotAttributeMasters)
                                        .Include(x => x.BotIntendMasters)
                                        .Include(x => x.BotSkillMasters)
                                        .Include(x => x.RuleMaster).ThenInclude(x => x.RuleType)
                                        .Include(x => x.RuleMaster).ThenInclude(x => x.RuleChannel).ThenInclude(x => x.Channel)
                                        .FirstOrDefaultAsync();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<AccountBot>> GetBotMasterByAccountId(int accountID)
        {
            try
            {
                return await _dbContext.AccountBot
                                        .AsNoTracking()
                                        .Where(x => x.AccountID == accountID)
                                        .Include(x => x.BotMaster)
                                        .Include(x => x.BotMaster.BotAttributeMasters)
                                        .Include(x => x.BotMaster.BotIntendMasters)
                                        .Include(x => x.BotMaster.BotSkillMasters)
                                        .Include(x=>x.BotMaster.RuleMaster).ThenInclude(x=>x.RuleType)
                                        .Include(x=>x.BotMaster.RuleMaster).ThenInclude(x=>x.RuleChannel).ThenInclude(x=>x.Channel)
                                        .ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> SaveBotMaster(BotMaster botMaster)
        {
            try
            {
                _dbContext.BotMaster.Add(botMaster);
                await _dbContext.SaveChangesAsync();
                return botMaster.BotMasterID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> UpdateBotMaster(BotMaster botMaster)
        {
            try
            {
                var existBotMaster = await _dbContext.BotMaster.AsNoTracking().FirstOrDefaultAsync(x => x.BotMasterID == botMaster.BotMasterID);
                if (existBotMaster != null)
                {
                    _dbContext.BotMaster.UpdateRange(botMaster);
                    await _dbContext.SaveChangesAsync();
                }
                return botMaster.BotMasterID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
