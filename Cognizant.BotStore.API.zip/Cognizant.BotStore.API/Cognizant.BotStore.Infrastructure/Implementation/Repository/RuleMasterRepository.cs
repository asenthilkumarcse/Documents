using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class RuleMasterRepository : IRuleMasterRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public RuleMasterRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteRuleMasterById(int rulemasterId)
        {
            try
            {
                var ruleChannel = _dbContext.RuleChannel.Where(s => s.RuleMasterID == rulemasterId).FirstOrDefault();
                if (ruleChannel != null)
                {
                    _dbContext.RuleChannel.Remove(ruleChannel);
                    await _dbContext.SaveChangesAsync();
                }

                var rulemaster = _dbContext.RuleMaster.Where(s => s.RuleMasterID == rulemasterId).FirstOrDefault<RuleMaster>();
                if (rulemaster != null)
                {
                    _dbContext.RuleMaster.Remove(rulemaster);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, rulemasterId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete RuleMasterById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "RuleMasterID -" + rulemasterId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<RuleMaster> GetRuleMasterById(int rulemasterId)
        {
            try
            {
                return await _dbContext.RuleMaster.AsNoTracking().Where(x => x.RuleMasterID == rulemasterId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<RuleMaster>> GetRuleMaster()
        {
            try
            {
                return await _dbContext.RuleMaster.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveRuleMaster(RuleMaster rulemaster)
        {
            try
            {
                var existsRuleMaster = await _dbContext.RuleMaster.AsNoTracking().FirstOrDefaultAsync(x => x.RuleName == rulemaster.RuleName);
                if (existsRuleMaster == null)
                {
                    _dbContext.RuleMaster.Add(rulemaster);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = rulemaster.RuleMasterID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, rulemaster.RuleName) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveRuleMaster()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateRuleMaster(RuleMaster rulemaster)
        {
            try
            {
                var existsRuleMaster = await _dbContext.RuleMaster.AsNoTracking().FirstOrDefaultAsync(x => x.RuleMasterID == rulemaster.RuleMasterID);
                if (existsRuleMaster != null)
                {
                    if (existsRuleMaster.RuleName != rulemaster.RuleName)
                    {
                        existsRuleMaster = await _dbContext.RuleMaster.AsNoTracking().FirstOrDefaultAsync(x => x.RuleName == rulemaster.RuleName);
                        if (existsRuleMaster != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, rulemaster.RuleName)
                            };
                        }
                        else
                        {
                            _dbContext.RuleMaster.UpdateRange(rulemaster);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.RuleMaster.UpdateRange(rulemaster);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, rulemaster.RuleMasterID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateRuleMaster()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }

        public async Task<List<RuleMaster>> GetRuleMasterByBotID(int botMasterID)
        {
            try
            {
                return await _dbContext.RuleMaster.AsNoTracking().Where(x => x.BotMasterID == botMasterID).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<RuleMasterModel>> GetRuleAccountBotByBotID(int botMasterID, int accountID)
        {
            List<RuleMasterModel> accountBots = await (from ruleMaster in _dbContext.RuleMaster.AsNoTracking().Where(x => x.BotMasterID == botMasterID)
                                                       select new RuleMasterModel
                                                       {
                                                           BotMasterID = ruleMaster.BotMasterID,
                                                           RuleName = ruleMaster.RuleName,
                                                           RuleMasterID = ruleMaster.RuleMasterID,
                                                           IsSelected = _dbContext.AccountBotRule.
                                                                                     AsNoTracking().Where(x => x.BotMasterID == botMasterID
                                                                                     && x.RuleMasterID == ruleMaster.RuleMasterID && x.AccountID == accountID).Count() > 0,
                                                           AccountBotRuleID = _dbContext.AccountBotRule.AsNoTracking().
                                                                                            Where(x => x.BotMasterID == botMasterID && x.RuleMasterID == ruleMaster.RuleMasterID
                                                                                            && x.AccountID == accountID).Select(x => x.AccountBotRuleID).FirstOrDefault()
                                                       }).ToListAsync();
            return accountBots;
        }
    }
}

