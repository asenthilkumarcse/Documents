using Cognizant.BotStore.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class BotUserRepository : IBotUserRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public BotUserRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task DeleteBotUserById(int botuserId)
        {
            try
            {
                var botuser = _dbContext.BotUser.Where(s => s.BotUserID == botuserId).FirstOrDefault<BotUser>();
                if (botuser != null)
                {
                    _dbContext.BotUser.Remove(botuser);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }
        public async Task<BotUser> GetBotUserById(int botuserId)
        {
            try
            {
                return await _dbContext.BotUser.AsNoTracking().Where(x => x.BotUserID == botuserId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }
        public async Task<List<BotUser>> GetBotUser()
        {
            try
            {
                return await _dbContext.BotUser.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }
        public async Task<int> SaveBotUser(BotUser botuser)
        {
            try
            {
                var existsBotUser = await _dbContext.BotUser.AsNoTracking().FirstOrDefaultAsync(x => x.UserName == botuser.UserName);
                if (existsBotUser == null)
                {
                    _dbContext.BotUser.Add(botuser);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.BotUser.UpdateRange(botuser);
                    await _dbContext.SaveChangesAsync();
                }
                return botuser.BotUserID;
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }
        public async Task<int> UpdateBotUser(BotUser botuser)
        {
            try
            {
                var existsBotUser = await _dbContext.BotUser.AsNoTracking().FirstOrDefaultAsync(x => x.BotUserID == botuser.BotUserID);
                if (existsBotUser == null)
                {
                    _dbContext.BotUser.Add(botuser);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.BotUser.UpdateRange(botuser);
                    await _dbContext.SaveChangesAsync();
                }
                return botuser.BotUserID;
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }

        public async Task<LoginResponse> ValidateUser(LoginRequest loginRequest)
        {
            try
            {
                var validateBotUser = await _dbContext.BotUser.
                                AsNoTracking().FirstOrDefaultAsync(x => x.UserName == loginRequest.UserName && x.Password == loginRequest.Password);

                if (validateBotUser != null)
                    return new LoginResponse { UserID = validateBotUser.BotUserID, UserName = validateBotUser.UserName, AccountID = validateBotUser.AccountID,IsClient= validateBotUser.IsClient };
                return new LoginResponse { ErrorDescription = "Invalid UserName and Password" };
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }

        public async Task<string> ChangePassword(ChangePassword changePassword)
        {
            try
            {
                var validateBotUser = await _dbContext.BotUser.
                                AsNoTracking().FirstOrDefaultAsync(x => x.BotUserID == changePassword.UserId && x.Password == changePassword.CurrentPassword);

                if (validateBotUser == null)
                {
                    return "Current Password is wrong";
                }
                var updatePassword = await _dbContext.BotUser.
                              AsNoTracking().FirstOrDefaultAsync(x => x.BotUserID == changePassword.UserId && x.Password == changePassword.CurrentPassword);

                if (updatePassword != null)
                {
                    updatePassword.Password = changePassword.NewPassword;
                    _dbContext.BotUser.UpdateRange(updatePassword);
                    await _dbContext.SaveChangesAsync();
                }

                return "Success";
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                throw ex;
            }
        }
        public async Task<ForgetPasswordResponse> ForgetPassword(ForgetPassword forgetPassword)
        {
            try
            {
                var validateBotUser = await _dbContext.BotUser.
                                AsNoTracking().FirstOrDefaultAsync(x => x.UserName == forgetPassword.UserName && x.Email == forgetPassword.Email);

                if (validateBotUser == null)
                {
                    return new ForgetPasswordResponse { Status = "User Name & Email does not match", StatusCode = 101 };
                }
                else
                {
                    return new ForgetPasswordResponse { Status = "Success", StatusCode = 400, Email = validateBotUser.Email, Password = validateBotUser.Password };
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception occurred in BotUserRepository", ex);
                return new ForgetPasswordResponse { Status = "Internal Error", StatusCode = 401 };
            }
        }
    }
}

