using Cognizant.BotStore.Core;
using EFCore.BulkExtensions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Infrastructure
{
    public class AccountBotRepository : IAccountBotRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public AccountBotRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task DeleteAccountBotById(int accountId, int botId)
        {
            try
            {
                var accountbot = _dbContext.AccountBot.Where(s => s.AccountID == accountId && s.BotMasterID == botId).FirstOrDefault();
                if (accountbot != null)
                {
                    _dbContext.AccountBot.Remove(accountbot);
                    await _dbContext.SaveChangesAsync();
                }
                var accountbotRule = _dbContext.AccountBotRule.Where(s => s.AccountID == accountId && s.BotMasterID == botId).FirstOrDefault();
                if (accountbotRule != null)
                {
                    _dbContext.AccountBotRule.Remove(accountbotRule);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<AccountBot> GetAccountBotById(int accountbotId)
        {
            try
            {
                return await _dbContext.AccountBot.AsNoTracking().Where(x => x.AccountBotID == accountbotId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<AccountBotDetails>> GetAccountBot()
        {
            try
            {
                List<AccountBotDetails> accountBots = await (from accountBot in _dbContext.AccountBot.AsNoTracking()
                                                             join account in _dbContext.Account.AsNoTracking() on accountBot.AccountID equals account.AccountID
                                                             join botMaster in _dbContext.BotMaster.AsNoTracking() on accountBot.BotMasterID equals botMaster.BotMasterID
                                                             select new AccountBotDetails
                                                             {
                                                                 AccountBotID = accountBot.AccountBotID,
                                                                 AccountID = accountBot.AccountID,
                                                                 BotMasterID = accountBot.BotMasterID,
                                                                 AccountName = account.AccountName,
                                                                 BotName = botMaster.BotName,
                                                             }).ToListAsync();

                return accountBots;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> SaveAccountBot(AccountBot accountbot)
        {
            try
            {
                var existsAccountBot = await _dbContext.AccountBot.AsNoTracking().
                    FirstOrDefaultAsync(x => x.AccountID == accountbot.AccountID && x.BotMasterID == accountbot.BotMasterID);

                if (existsAccountBot == null)
                {
                    _dbContext.AccountBot.Add(accountbot);
                    await _dbContext.SaveChangesAsync();
                }
                //else
                //{
                //    _dbContext.AccountBot.UpdateRange(accountbot);
                //    await _dbContext.SaveChangesAsync();
                //}
                return accountbot.AccountBotID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<int> UpdateAccountBot(AccountBot accountbot)
        {
            try
            {
                var existsAccountBot = await _dbContext.AccountBot.AsNoTracking().FirstOrDefaultAsync(x => x.AccountBotID == accountbot.AccountBotID);
                if (existsAccountBot == null)
                {
                    _dbContext.AccountBot.Add(accountbot);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    _dbContext.AccountBot.UpdateRange(accountbot);
                    await _dbContext.SaveChangesAsync();
                }
                return accountbot.AccountBotID;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<AccountBotDetails>> GettBotByAccountId(int accountId)
        {
            List<AccountBotDetails> accountBots = await (from botMaster in _dbContext.BotMaster.AsNoTracking()
                                                         select new AccountBotDetails
                                                         {
                                                             BotMasterID = botMaster.BotMasterID,
                                                             BotName = botMaster.BotName,
                                                             IsSelected = _dbContext.AccountBot.
                                                             AsNoTracking().Where(x => x.AccountID == accountId && x.BotMasterID == botMaster.BotMasterID).Count() > 0,
                                                             IsRuleEnabled = botMaster.IsRuleEnabled
                                                         }).ToListAsync();

            return accountBots;
        }

        public async Task DeleteAccount(int accountId, int BotId)
        {
            try
            {
                var accountbot = _dbContext.AccountBot.Where(s => s.AccountID == accountId && s.BotMasterID == BotId).FirstOrDefault();
                if (accountbot != null)
                {
                    _dbContext.AccountBot.Remove(accountbot);
                    await _dbContext.SaveChangesAsync();
                }
                var accountBotRule = _dbContext.AccountBotRule.Where(s => s.AccountID == accountId && s.BotMasterID == BotId).ToList();
                if (accountBotRule != null)
                {
                    await _dbContext.BulkDeleteAsync(accountBotRule);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

