using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class CategoryTypeValueRepository : ICategoryTypeValueRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public CategoryTypeValueRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteCategoryTypeValueById(int categorytypevalueId)
        {
            try
            {
                var categorytypevalue = _dbContext.CategoryTypeValue.Where(s => s.CategoryTypeValueID == categorytypevalueId).FirstOrDefault<CategoryTypeValue>();
                if (categorytypevalue != null)
                {
                    _dbContext.CategoryTypeValue.Remove(categorytypevalue);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, categorytypevalueId) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete CategoryTypeValueById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "CategoryTypeValueID -" + categorytypevalueId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<CategoryTypeValue> GetCategoryTypeValueById(int categorytypevalueId)
        {
            try
            {
                return await _dbContext.CategoryTypeValue.AsNoTracking().Where(x => x.CategoryTypeValueID == categorytypevalueId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<CategoryTypeValue>> GetCategoryTypeValue()
        {
            try
            {
                return await _dbContext.CategoryTypeValue.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveCategoryTypeValue(CategoryTypeValue categorytypevalue)
        {
            try
            {
                var existsCategoryTypeValue = await _dbContext.CategoryTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.Description == categorytypevalue.Description);
                if (existsCategoryTypeValue == null)
                {
                    _dbContext.CategoryTypeValue.Add(categorytypevalue);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = categorytypevalue.CategoryTypeValueID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, categorytypevalue.Description) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveCategoryTypeValue()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateCategoryTypeValue(CategoryTypeValue categorytypevalue)
        {
            try
            {
                var existsCategoryTypeValue = await _dbContext.CategoryTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.CategoryTypeValueID == categorytypevalue.CategoryTypeValueID);
                if (existsCategoryTypeValue != null)
                {
                    if (existsCategoryTypeValue.Description != categorytypevalue.Description)
                    {
                        existsCategoryTypeValue = await _dbContext.CategoryTypeValue.AsNoTracking().FirstOrDefaultAsync(x => x.Description == categorytypevalue.Description);
                        if (existsCategoryTypeValue != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, categorytypevalue.Description)
                            };
                        }
                        else
                        {
                            _dbContext.CategoryTypeValue.UpdateRange(categorytypevalue);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.CategoryTypeValue.UpdateRange(categorytypevalue);
                        await _dbContext.SaveChangesAsync();
                    }
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.NotExistsCode, StatusDescription = string.Format(CommonVariable.NotExistsMessage, categorytypevalue.CategoryTypeValueID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateCategoryTypeValue()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

