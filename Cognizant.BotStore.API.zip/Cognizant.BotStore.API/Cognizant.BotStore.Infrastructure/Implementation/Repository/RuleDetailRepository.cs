using Microsoft.EntityFrameworkCore;
using Cognizant.BotStore.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Serilog;

namespace Cognizant.BotStore.Infrastructure
{
    public class RuleDetailRepository : IRuleDetailRepository
    {
        private readonly BotStoreDBContext _dbContext;
        public RuleDetailRepository(BotStoreDBContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<BaseResponse> DeleteRuleDetailById(int ruledetailId)
        {
            try
            {
                var ruledetail = _dbContext.RuleDetail.Where(s => s.RuleDetailID == ruledetailId).FirstOrDefault<RuleDetail>();
                if (ruledetail != null)
                {
                    _dbContext.RuleDetail.Remove(ruledetail);
                    await _dbContext.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in Delete RuleDetailById()");
                if (ex.InnerException.Message.Contains("The DELETE statement conflicted with the REFERENCE"))
                {
                    return new BaseResponse
                    {
                        StatusCode = CommonVariable.ReferenceErrorCode,
                        StatusDescription = string.Format(CommonVariable.ReferenceErrorMessage, "RuleDetailID -" + ruledetailId.ToString())
                    };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
                }
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
        public async Task<RuleDetail> GetRuleDetailById(int ruledetailId)
        {
            try
            {
                return await _dbContext.RuleDetail.AsNoTracking().Where(x => x.RuleDetailID == ruledetailId).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<RuleDetail>> GetRuleDetail()
        {
            try
            {
                return await _dbContext.RuleDetail.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<BaseResponse> SaveRuleDetail(RuleDetail ruledetail)
        {
            try
            {
                var existsRuleDetail = await _dbContext.RuleDetail.AsNoTracking().FirstOrDefaultAsync(x => x.RuleMasterID == ruledetail.RuleMasterID);
                if (existsRuleDetail == null)
                {
                    _dbContext.RuleDetail.Add(ruledetail);
                    await _dbContext.SaveChangesAsync();
                    return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage, ID = ruledetail.RuleDetailID };
                }
                else
                {
                    return new BaseResponse { StatusCode = CommonVariable.AlreadyExistsCode, StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, ruledetail.RuleMasterID) };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in SaveRuleDetail()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
        }
        public async Task<BaseResponse> UpdateRuleDetail(RuleDetail ruledetail)
        {
            try
            {
                var existsRuleDetail = await _dbContext.RuleDetail.AsNoTracking().FirstOrDefaultAsync(x => x.RuleDetailID == ruledetail.RuleDetailID);
                if (existsRuleDetail != null)
                {
                    if (existsRuleDetail.RuleMasterID != ruledetail.RuleMasterID)
                    {
                        existsRuleDetail = await _dbContext.RuleDetail.AsNoTracking().FirstOrDefaultAsync(x => x.RuleMasterID == ruledetail.RuleMasterID);
                        if (existsRuleDetail != null)
                        {
                            return new BaseResponse
                            {
                                StatusCode = CommonVariable.AlreadyExistsCode,
                                StatusDescription = string.Format(CommonVariable.AlreadyExistsMessage, ruledetail.RuleMasterID)
                            };
                        }
                        else
                        {
                            _dbContext.RuleDetail.UpdateRange(ruledetail);
                            await _dbContext.SaveChangesAsync();
                        }
                    }
                    else
                    {
                        _dbContext.RuleDetail.UpdateRange(ruledetail);
                        await _dbContext.SaveChangesAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.StackTrace, "Error Occured in UpdateRuleDetail()");
                return new BaseResponse { StatusCode = CommonVariable.InternalErrorCode, StatusDescription = CommonVariable.InternalErrorMessage };
            }
            return new BaseResponse { StatusCode = CommonVariable.SuccessCode, StatusDescription = CommonVariable.SuccessMessage };
        }
    }
}

