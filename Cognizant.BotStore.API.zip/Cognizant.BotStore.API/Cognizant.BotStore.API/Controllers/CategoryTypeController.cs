using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/categorytype")]
    [ApiController]
    public class CategoryTypeController : ControllerBase
    {
        private readonly ICategoryTypeService _categorytypeService;
        public CategoryTypeController(ICategoryTypeService categorytypeService)
        {
            _categorytypeService = categorytypeService;
        }
        [HttpGet]
        public async Task<List<CategoryType>> GetCategoryType() => await _categorytypeService.GetCategoryType();
        [HttpPost]
        public async Task<BaseResponse> SaveCategoryType(CategoryType categorytype) => await _categorytypeService.SaveCategoryType(categorytype);
        [HttpPut]
        public async Task<BaseResponse> UpdateCategoryType(CategoryType categorytype) => await _categorytypeService.UpdateCategoryType(categorytype);
        [HttpGet("{categorytypeid}")]
        public async Task<CategoryType> GetCategoryTypeById(int categorytypeid) => await _categorytypeService.GetCategoryTypeById(categorytypeid);
        [HttpDelete("{categorytypeid}")]
        public async Task<BaseResponse> DeleteCategoryType(int categorytypeid) => await _categorytypeService.DeleteCategoryTypeById(categorytypeid);
    }
}
