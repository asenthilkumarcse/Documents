﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/intenddetails")]
    [ApiController]
    public class IntendDetailsController : ControllerBase
    {
        private readonly IIntendDetailsService _intendDetailsService;
        public IntendDetailsController(IIntendDetailsService intendDetailsService)
        {
            _intendDetailsService = intendDetailsService;
        }
        [HttpGet]
        public async Task<List<IntendDetail>> GetIntentDetails() => await _intendDetailsService.GetIntendDetails();
        [HttpPost]
        public async Task<int> SaveIntentDetails(IntendDetail intendDetails) => await _intendDetailsService.SaveIntendDetails(intendDetails);
        [HttpDelete]
        public async Task DeleteBotIntentDetailById(int intentDetailId) => await _intendDetailsService.DeleteBotIntentDetailById(intentDetailId);
    }
}