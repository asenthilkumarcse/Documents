using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/conditiontype")]
    [ApiController]
    public class ConditionTypeController : ControllerBase
    {
        private readonly IConditionTypeService _conditiontypeService;
        public ConditionTypeController(IConditionTypeService conditiontypeService)
        {
            _conditiontypeService = conditiontypeService;
        }
        [HttpGet]
        public async Task<List<ConditionType>> GetConditionType() => await _conditiontypeService.GetConditionType();
        [HttpPost]
        public async Task<BaseResponse> SaveConditionType(ConditionType conditiontype) => await _conditiontypeService.SaveConditionType(conditiontype);
        [HttpPut]
        public async Task<BaseResponse> UpdateConditionType(ConditionType conditiontype) => await _conditiontypeService.UpdateConditionType(conditiontype);
        [HttpGet("{conditiontypeid}")]
        public async Task<ConditionType> GetConditionTypeById(int conditiontypeid) => await _conditiontypeService.GetConditionTypeById(conditiontypeid);
        [HttpDelete("{conditiontypeid}")]
        public async Task<BaseResponse> DeleteConditionType(int conditiontypeid) => await _conditiontypeService.DeleteConditionTypeById(conditiontypeid);
    }
}
