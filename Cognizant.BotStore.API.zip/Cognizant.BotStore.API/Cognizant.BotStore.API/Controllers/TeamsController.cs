﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/team")]
    [ApiController]
    public class TeamsController : ControllerBase
    {
        private readonly ITeamDetailsService _teamDetailsService;
        public TeamsController(ITeamDetailsService teamDetailsService)
        {
            _teamDetailsService = teamDetailsService;
        }
        [HttpGet]
        public async Task<List<TeamDetail>> GetTeams() => await _teamDetailsService.GetTeamDetails();
        [HttpGet("GetTeamDetailsByAccountID")]
        public async Task<List<TeamDetail>> GetTeamDetailsByAccountID(int accountID) => await _teamDetailsService.GetTeamDetailsByAccountID(accountID);
        [HttpPost]
        public async Task<int> SaveTeamDetails(TeamDetail teamDetails) => await _teamDetailsService.SaveTeamDetails(teamDetails);

        [HttpPut]
        public async Task<int> UpdateTeamDetail(TeamDetail teamDetail) => await _teamDetailsService.UpdateTeamDetail(teamDetail);
        [HttpGet("{teamDetailid}")]
        public async Task<TeamDetail> GetTeamDetailById(int teamDetailid) => await _teamDetailsService.GetTeamDetailById(teamDetailid);
        [HttpDelete("{teamDetailid}")]
        public async Task DeleteTeamDetail(int teamDetailid) => await _teamDetailsService.DeleteTeamDetailById(teamDetailid);
        [HttpGet("assignedteams")]
        public async Task<List<TeamDetail>> GetAssignedTeams(int botId) => await _teamDetailsService.GetAssignedTeamDetailsByBotId(botId);
        [HttpGet("assignedTeamDetailsByAccountID")]
        public async Task<List<TeamDetail>> GetAssignedTeamDetailsByAccountID(int botId, int accountID) => await _teamDetailsService.GetAssignedTeamDetailsByAccountID(botId, accountID);

        [HttpGet("unassignedteams")]
        public async Task<List<TeamDetail>> GetUnAssignedTeams(int botId) => await _teamDetailsService.GetUnAssignedTeamDetailsForBot(botId);
        [HttpGet("unAssignedTeamDetailsByAccountID")]
        public async Task<List<TeamDetail>> GetUnAssignedTeamDetailsByAccountID(int botId, int accountID) => await _teamDetailsService.GetUnAssignedTeamDetailsByAccountID(botId, accountID);
    }
}