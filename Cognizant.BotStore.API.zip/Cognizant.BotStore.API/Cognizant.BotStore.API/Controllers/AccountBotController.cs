using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/accountbot")]
    [ApiController]
    public class AccountBotController : ControllerBase
    {
        private readonly IAccountBotService _accountbotService;
        public AccountBotController(IAccountBotService accountbotService)
        {
            _accountbotService = accountbotService;
        }
        [HttpGet]
        public async Task<List<AccountBotDetails>> GetAccountBot() => await _accountbotService.GetAccountBot();
        [HttpPost]
        public async Task<int> SaveAccountBot(AccountBot accountbot) => await _accountbotService.SaveAccountBot(accountbot);
        [HttpPut]
        public async Task<int> UpdateAccountBot(AccountBot accountbot) => await _accountbotService.UpdateAccountBot(accountbot);
        [HttpGet("{accountbotid}")]
        public async Task<AccountBot> GetAccountBotById(int accountbotId) => await _accountbotService.GetAccountBotById(accountbotId);
        [HttpGet("account/{accountid}")]
        public async Task<List<AccountBotDetails>> GettBotByAccountId(int accountid) => await _accountbotService.GettBotByAccountId(accountid);
        [HttpDelete("{accountid}/{botid}")]
        public async Task DeleteAccountBot(int accountid,int botid) => await _accountbotService.DeleteAccountBotById(accountid, botid);
        [HttpDelete("account/{accountid}/{botid}")]
        public async Task DeleteAccount(int accountid, int botid) => await _accountbotService.DeleteAccount(accountid, botid);
    }
}
