using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/rulemaster")]
    [ApiController]
    public class RuleMasterController : ControllerBase
    {
        private readonly IRuleMasterService _rulemasterService;
        public RuleMasterController(IRuleMasterService rulemasterService)
        {
            _rulemasterService = rulemasterService;
        }
        [HttpGet]
        public async Task<List<RuleMaster>> GetRuleMaster() => await _rulemasterService.GetRuleMaster();
        [HttpPost]
        public async Task<BaseResponse> SaveRuleMaster(RuleMaster rulemaster) => await _rulemasterService.SaveRuleMaster(rulemaster);
        [HttpPut]
        public async Task<BaseResponse> UpdateRuleMaster(RuleMaster rulemaster) => await _rulemasterService.UpdateRuleMaster(rulemaster);
        [HttpGet("{rulemasterid}")]
        public async Task<RuleMaster> GetRuleMasterById(int rulemasterid) => await _rulemasterService.GetRuleMasterById(rulemasterid);
        [HttpGet("accountbotrule/{botmasterid}/{accountid}")]
        public async Task<List<RuleMasterModel>> GetRuleAccountBotByBotID(int botmasterid, int accountid) =>
            await _rulemasterService.GetRuleAccountBotByBotID(botmasterid, accountid);
        [HttpGet("rulebybotid/{botmasterid}")]
        public async Task<List<RuleMaster>> GetRuleMasterByBotID(int botmasterid) => await _rulemasterService.GetRuleMasterByBotID(botmasterid);
        [HttpDelete("{rulemasterid}")]
        public async Task<BaseResponse> DeleteRuleMaster(int rulemasterid) => await _rulemasterService.DeleteRuleMasterById(rulemasterid);
    }
}
