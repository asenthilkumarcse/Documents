using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/botenquiry")]
    [ApiController]
    public class BotEnquiryController : ControllerBase
    {
        private readonly IBotEnquiryService _botenquiryService;
        public BotEnquiryController(IBotEnquiryService botenquiryService)
        {
            _botenquiryService = botenquiryService;
        }
        [HttpGet]
        public async Task<List<BotEnquiry>> GetBotEnquiry() => await _botenquiryService.GetBotEnquiry();
        [HttpPost]
        public async Task<BaseResponse> SaveBotEnquiry(BotEnquiry botenquiry) => await _botenquiryService.SaveBotEnquiry(botenquiry);
        [HttpPut]
        public async Task<BaseResponse> UpdateBotEnquiry(BotEnquiry botenquiry) => await _botenquiryService.UpdateBotEnquiry(botenquiry);
        [HttpGet("{botenquiryid}")]
        public async Task<BotEnquiry> GetBotEnquiryById(int botenquiryid) => await _botenquiryService.GetBotEnquiryById(botenquiryid);
        [HttpDelete("{botenquiryid}")]
        public async Task<BaseResponse> DeleteBotEnquiry(int botenquiryid) => await _botenquiryService.DeleteBotEnquiryById(botenquiryid);
    }
}
