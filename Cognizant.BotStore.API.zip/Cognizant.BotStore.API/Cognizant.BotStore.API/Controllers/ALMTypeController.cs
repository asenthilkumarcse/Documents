using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/almtype")]
    [ApiController]
    public class ALMTypeController : ControllerBase
    {
        private readonly IALMTypeService _almtypeService;
        public ALMTypeController(IALMTypeService almtypeService)
        {
            _almtypeService = almtypeService;
        }
        [HttpGet]
        public async Task<List<ALMType>> GetALMType() => await _almtypeService.GetALMType();
        [HttpPost]
        public async Task<BaseResponse> SaveALMType(ALMType almtype) => await _almtypeService.SaveALMType(almtype);
        [HttpPut]
        public async Task<BaseResponse> UpdateALMType(ALMType almtype) => await _almtypeService.UpdateALMType(almtype);
        [HttpGet("{almtypeid}")]
        public async Task<ALMType> GetALMTypeById(int almtypeid) => await _almtypeService.GetALMTypeById(almtypeid);
        [HttpDelete("{almtypeid}")]
        public async Task<BaseResponse> DeleteALMType(int almtypeid) => await _almtypeService.DeleteALMTypeById(almtypeid);
    }
}
