using Cognizant.BotStore.Core;
using Cognizant.BotStore.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serilog;
using System.Collections.Generic;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/botuser")]
    [ApiController]
    public class BotUserController : ControllerBase
    {
        private readonly IBotUserService _botuserService;
        private readonly SmtpClient _smtpClient;
        private readonly IConfiguration _configurations;
        public BotUserController(IBotUserService botuserService, SmtpClient smtpClient, IConfiguration configuration)
        {
            _botuserService = botuserService;
            _smtpClient = smtpClient;
            _configurations = configuration;
        }
        [HttpGet]
        public async Task<List<BotUser>> GetBotUser() => await _botuserService.GetBotUser();
        [HttpPost]
        public async Task<int> SaveBotUser(BotUser botuser) => await _botuserService.SaveBotUser(botuser);
        [HttpPut]
        public async Task<int> UpdateBotUser(BotUser botuser) => await _botuserService.UpdateBotUser(botuser);
        [HttpGet("{botuserid}")]
        public async Task<BotUser> GetBotUserById(int botuserid) => await _botuserService.GetBotUserById(botuserid);
        [HttpDelete("{botuserid}")]
        public async Task DeleteBotUser(int botuserId) => await _botuserService.DeleteBotUserById(botuserId);

        [HttpPost("validateuser")]
        public async Task<LoginResponse> ValidateBotUser(LoginRequest loginRequest) => await _botuserService.ValidateUser(loginRequest);
        [HttpPost("changepassword")]
        public async Task<string> ChangePassword(ChangePassword changePassword) => await _botuserService.ChangePassword(changePassword);
        [HttpPost("forgetpassword")]
        public async Task<ForgetPasswordResponse> ForgetPassword(ForgetPassword forgetPassword)
        {
            var response = await _botuserService.ForgetPassword(forgetPassword);
            try
            {
                if (response.StatusCode == 400)
                {
                    var decryptSetting = _configurations.GetSection(nameof(DecryptionSetting));
                    var encryptionMarkerStart = decryptSetting[nameof(DecryptionSetting.EncryptionMarkerStart)];
                    var encryptionMarkerEnd = decryptSetting[nameof(DecryptionSetting.EncryptionMarkerEnd)];

                    string password = ConfigurationProviderHelper.DecryptString(response.Password, "BotStore_Dev", encryptionMarkerStart, encryptionMarkerEnd);

                    _smtpClient.Host = _smtpClient.Host;
                    _smtpClient.Port = _smtpClient.Port;
                    _smtpClient.Send(new MailMessage(
                        from: "botstoreadmin@cognizant.com",
                        to: response.Email,
                        subject: "Password Request",
                        body: "Hi, \n\n   Your Password is:" + password + "\n\n Thanks \n Bot Store Support Team"
                        ));
                }
            }
            catch (System.Exception ex)
            {
                Log.Error("Exception occurred in BotUserController - ForgetPassword", ex);
            }
            return response;
        }
    }
}
