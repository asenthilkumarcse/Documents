﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/attributedetails")]
    [ApiController]
    public class AttributeDetailsController : ControllerBase
    {
        private readonly IAttributeDetailsService _attributeDetailsService;
        public AttributeDetailsController(IAttributeDetailsService attributeDetailsService)
        {
            _attributeDetailsService = attributeDetailsService;
        }
        [HttpGet]
        public async Task<List<AttributeDetail>> GetAttributes() => await _attributeDetailsService.GetAttributeDetails();
        [HttpPost]
        public async Task<int> SaveAttributeDetails(AttributeDetail attributeDetails) => await _attributeDetailsService.SaveAttributeDetails(attributeDetails);
        [HttpDelete]
        public async Task DeleteBotAttributeDetailsById(int attributeDetailsId) => await _attributeDetailsService.DeleteBotAttributeDetailsById(attributeDetailsId);
    }
}