using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/rulechannel")]
    [ApiController]
    public class RuleChannelController : ControllerBase
    {
        private readonly IRuleChannelService _rulechannelService;
        public RuleChannelController(IRuleChannelService rulechannelService)
        {
            _rulechannelService = rulechannelService;
        }
        [HttpGet]
        public async Task<List<RuleChannel>> GetRuleChannel() => await _rulechannelService.GetRuleChannel();
        [HttpPost]
        public async Task<BaseResponse> SaveRuleChannel(RuleChannel rulechannel) => await _rulechannelService.SaveRuleChannel(rulechannel);
        [HttpPut]
        public async Task<BaseResponse> UpdateRuleChannel(RuleChannel rulechannel) => await _rulechannelService.UpdateRuleChannel(rulechannel);
        [HttpGet("{rulechannelid}")]
        public async Task<RuleChannel> GetRuleChannelById(int rulechannelid) => await _rulechannelService.GetRuleChannelById(rulechannelid);
        [HttpDelete("{rulechannelid}")]
        public async Task<BaseResponse> DeleteRuleChannel(int rulechannelid) => await _rulechannelService.DeleteRuleChannelById(rulechannelid);
    }
}
