﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/botlist")]
    [ApiController]
    public class BotListController : ControllerBase
    {
        private readonly IBotMasterService _botMasterService;
        public BotListController(IBotMasterService botMasterService)
        {
            _botMasterService = botMasterService;
        }
        [HttpGet("{id}")]
        public async Task<BotMaster> GetBotById(int id) => await _botMasterService.GetBotMasterById(id);
        [HttpGet]
        public async Task<List<BotMaster>> GetBots() => await _botMasterService.GetBotMaster();

        [HttpPost]
        public async Task SaveBotDetails(BotMaster botMaster) => await _botMasterService.SaveBotMaster(botMaster);
        [HttpDelete("{id}")]
        public async Task DeletetBotById(int id) => await _botMasterService.DeletetBotById(id);
    }
}