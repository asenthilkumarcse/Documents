using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/ruledetail")]
    [ApiController]
    public class RuleDetailController : ControllerBase
    {
        private readonly IRuleDetailService _ruledetailService;
        public RuleDetailController(IRuleDetailService ruledetailService)
        {
            _ruledetailService = ruledetailService;
        }
        [HttpGet]
        public async Task<List<RuleDetail>> GetRuleDetail() => await _ruledetailService.GetRuleDetail();
        [HttpPost]
        public async Task<BaseResponse> SaveRuleDetail(RuleDetail ruledetail) => await _ruledetailService.SaveRuleDetail(ruledetail);
        [HttpPut]
        public async Task<BaseResponse> UpdateRuleDetail(RuleDetail ruledetail) => await _ruledetailService.UpdateRuleDetail(ruledetail);
        [HttpGet("{ruledetailid}")]
        public async Task<RuleDetail> GetRuleDetailById(int ruledetailid) => await _ruledetailService.GetRuleDetailById(ruledetailid);
        [HttpDelete("{ruledetailid}")]
        public async Task<BaseResponse> DeleteRuleDetail(int ruledetailid) => await _ruledetailService.DeleteRuleDetailById(ruledetailid);
    }
}
