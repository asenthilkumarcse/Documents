using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/conditiontypevalue")]
    [ApiController]
    public class ConditionTypeValueController : ControllerBase
    {
        private readonly IConditionTypeValueService _conditiontypevalueService;
        public ConditionTypeValueController(IConditionTypeValueService conditiontypevalueService)
        {
            _conditiontypevalueService = conditiontypevalueService;
        }
        [HttpGet]
        public async Task<List<ConditionTypeValue>> GetConditionTypeValue() => await _conditiontypevalueService.GetConditionTypeValue();
        [HttpPost]
        public async Task<BaseResponse> SaveConditionTypeValue(ConditionTypeValue conditiontypevalue) => await _conditiontypevalueService.SaveConditionTypeValue(conditiontypevalue);
        [HttpPut]
        public async Task<BaseResponse> UpdateConditionTypeValue(ConditionTypeValue conditiontypevalue) => await _conditiontypevalueService.UpdateConditionTypeValue(conditiontypevalue);
        [HttpGet("{conditiontypevalueid}")]
        public async Task<ConditionTypeValue> GetConditionTypeValueById(int conditiontypevalueid) => await _conditiontypevalueService.GetConditionTypeValueById(conditiontypevalueid);
        [HttpDelete("{conditiontypevalueid}")]
        public async Task<BaseResponse> DeleteConditionTypeValue(int conditiontypevalueid) => await _conditiontypevalueService.DeleteConditionTypeValueById(conditiontypevalueid);
    }
}
