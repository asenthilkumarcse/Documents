using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/ruletype")]
    [ApiController]
    public class RuleTypeController : ControllerBase
    {
        private readonly IRuleTypeService _ruletypeService;
        public RuleTypeController(IRuleTypeService ruletypeService)
        {
            _ruletypeService = ruletypeService;
        }
        [HttpGet]
        public async Task<List<RuleType>> GetRuleType() => await _ruletypeService.GetRuleType();
        [HttpPost]
        public async Task<BaseResponse> SaveRuleType(RuleType ruletype) => await _ruletypeService.SaveRuleType(ruletype);
        [HttpPut]
        public async Task<BaseResponse> UpdateRuleType(RuleType ruletype) => await _ruletypeService.UpdateRuleType(ruletype);
        [HttpGet("{ruletypeid}")]
        public async Task<RuleType> GetRuleTypeById(int ruletypeid) => await _ruletypeService.GetRuleTypeById(ruletypeid);
        [HttpDelete("{ruletypeid}")]
        public async Task<BaseResponse> DeleteRuleType(int ruletypeid) => await _ruletypeService.DeleteRuleTypeById(ruletypeid);
    }
}
