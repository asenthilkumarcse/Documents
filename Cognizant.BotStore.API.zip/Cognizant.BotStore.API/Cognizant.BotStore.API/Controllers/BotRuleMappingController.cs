using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/botrulemapping")]
    [ApiController]
    public class BotRuleMappingController : ControllerBase
    {
        private readonly IBotRuleMappingService _botrulemappingService;
        public BotRuleMappingController(IBotRuleMappingService botrulemappingService)
        {
            _botrulemappingService = botrulemappingService;
        }
        [HttpGet]
        public async Task<List<BotRuleMapping>> GetBotRuleMapping() => await _botrulemappingService.GetBotRuleMapping();
        [HttpPost]
        public async Task<BaseResponse> SaveBotRuleMapping(BotRuleMapping botrulemapping) => await _botrulemappingService.SaveBotRuleMapping(botrulemapping);
        [HttpPut]
        public async Task<BaseResponse> UpdateBotRuleMapping(BotRuleMapping botrulemapping) => await _botrulemappingService.UpdateBotRuleMapping(botrulemapping);
        [HttpGet("{botrulemappingid}")]
        public async Task<BotRuleMapping> GetBotRuleMappingById(int botrulemappingid) => await _botrulemappingService.GetBotRuleMappingById(botrulemappingid);
        [HttpDelete("{botrulemappingid}")]
        public async Task<BaseResponse> DeleteBotRuleMapping(int botrulemappingid) => await _botrulemappingService.DeleteBotRuleMappingById(botrulemappingid);
    }
}
