using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/categorytypevalue")]
    [ApiController]
    public class CategoryTypeValueController : ControllerBase
    {
        private readonly ICategoryTypeValueService _categorytypevalueService;
        public CategoryTypeValueController(ICategoryTypeValueService categorytypevalueService)
        {
            _categorytypevalueService = categorytypevalueService;
        }
        [HttpGet]
        public async Task<List<CategoryTypeValue>> GetCategoryTypeValue() => await _categorytypevalueService.GetCategoryTypeValue();
        [HttpPost]
        public async Task<BaseResponse> SaveCategoryTypeValue(CategoryTypeValue categorytypevalue) => await _categorytypevalueService.SaveCategoryTypeValue(categorytypevalue);
        [HttpPut]
        public async Task<BaseResponse> UpdateCategoryTypeValue(CategoryTypeValue categorytypevalue) => await _categorytypevalueService.UpdateCategoryTypeValue(categorytypevalue);
        [HttpGet("{categorytypevalueid}")]
        public async Task<CategoryTypeValue> GetCategoryTypeValueById(int categorytypevalueid) => await _categorytypevalueService.GetCategoryTypeValueById(categorytypevalueid);
        [HttpDelete("{categorytypevalueid}")]
        public async Task<BaseResponse> DeleteCategoryTypeValue(int categorytypevalueid) => await _categorytypevalueService.DeleteCategoryTypeValueById(categorytypevalueid);
    }
}
