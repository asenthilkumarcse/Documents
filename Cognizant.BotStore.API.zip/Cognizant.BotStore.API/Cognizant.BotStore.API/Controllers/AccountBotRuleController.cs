using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/accountbotrule")]
    [ApiController]
    public class AccountBotRuleController : ControllerBase
    {
        private readonly IAccountBotRuleService _accountbotruleService;
        public AccountBotRuleController(IAccountBotRuleService accountbotruleService)
        {
            _accountbotruleService = accountbotruleService;
        }
        [HttpGet]
        public async Task<List<AccountBotRule>> GetAccountBotRule() => await _accountbotruleService.GetAccountBotRule();
        [HttpPost]
        public async Task<BaseResponse> SaveAccountBotRule(AccountBotRule accountbotrule) => await _accountbotruleService.SaveAccountBotRule(accountbotrule);
        [HttpPost("bulksave")]
        public async Task<BaseResponse> BulkSaveAccountBotRule(IList<AccountBotRule> accountbotrule) =>
                                                                await _accountbotruleService.BulkSaveAccountBotRule(accountbotrule);
        [HttpPut]
        public async Task<BaseResponse> UpdateAccountBotRule(AccountBotRule accountbotrule) => await _accountbotruleService.UpdateAccountBotRule(accountbotrule);
        [HttpGet("{accountbotruleid}")]
        public async Task<AccountBotRule> GetAccountBotRuleById(int accountbotruleid) => await _accountbotruleService.GetAccountBotRuleById(accountbotruleid);
        [HttpDelete("{accountbotruleid}")]
        public async Task<BaseResponse> DeleteAccountBotRule(int accountbotruleid) => await _accountbotruleService.DeleteAccountBotRuleById(accountbotruleid);
        [HttpPost("bulkdelete")]
        public async Task<BaseResponse> DeleteAccountBotRule(List<AccountBotRule> accountBotRules) => await _accountbotruleService.DeleteAccountBotRule(accountBotRules);
        [HttpDelete("{accountid}/{botid}")]
        public async Task<BaseResponse> DeleteRuleByAccountBotID(int accountid, int botid) =>
            await _accountbotruleService.DeleteRuleByAccountBotID(accountid, botid);
    }
}
