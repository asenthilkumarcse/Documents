using Microsoft.AspNetCore.Mvc;
using Cognizant.BotStore.Core;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API
{
    [Route("api/channel")]
    [ApiController]
    public class ChannelController : ControllerBase
    {
        private readonly IChannelService _channelService;
        public ChannelController(IChannelService channelService)
        {
            _channelService = channelService;
        }
        [HttpGet]
        public async Task<List<Channel>> GetChannel() => await _channelService.GetChannel();
        [HttpPost]
        public async Task<BaseResponse> SaveChannel(Channel channel) => await _channelService.SaveChannel(channel);
        [HttpPut]
        public async Task<BaseResponse> UpdateChannel(Channel channel) => await _channelService.UpdateChannel(channel);
        [HttpGet("{channelid}")]
        public async Task<Channel> GetChannelById(int channelid) => await _channelService.GetChannelById(channelid);
        [HttpDelete("{channelid}")]
        public async Task<BaseResponse> DeleteChannel(int channelid) => await _channelService.DeleteChannelById(channelid);
    }
}
