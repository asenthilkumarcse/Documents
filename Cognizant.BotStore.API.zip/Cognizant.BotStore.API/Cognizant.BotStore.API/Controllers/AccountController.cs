using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/account")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;
        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }
        [HttpGet]
        public async Task<List<Account>> GetAccount() => await _accountService.GetAccount();
        [HttpPost]
        public async Task<int> SaveAccount(Account account) => await _accountService.SaveAccount(account);
        [HttpPut]
        public async Task<int> UpdateAccount(Account account) => await _accountService.UpdateAccount(account);
        [HttpGet("{accountid}")]
        public async Task<Account> GetAccountById(int accountId) => await _accountService.GetAccountById(accountId);
        [HttpDelete("{accountid}")]
        public async Task DeleteAccount(int accountId) => await _accountService.DeleteAccountById(accountId);
    }
}
