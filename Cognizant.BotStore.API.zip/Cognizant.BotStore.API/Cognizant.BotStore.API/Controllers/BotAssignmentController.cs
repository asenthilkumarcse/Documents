﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/botassignment")]
    [ApiController]
    public class BotAssignmentController : ControllerBase
    {
        private readonly IBotAssignmentService _botAssignmentService;
        public BotAssignmentController(IBotAssignmentService botAssignmentService)
        {
            _botAssignmentService = botAssignmentService;
        }
        //[HttpGet]
        //public async Task<List<BotAssignment>> GetBotAssignment() => await _botAssignmentService.GetBotAssignment();

        [HttpGet("{botID}")]
        public async Task<List<BotAssignment>> GetBotAssignmentByBotID(int botID)
        {
            return await _botAssignmentService.GetBotAssignmentByBotID(botID);
        }

        [HttpGet]
        public async Task<BotAssignment> GetBotAssignmentByTeam(int botID, int teamID)
        {
            return await _botAssignmentService.GetBotAssignmentByTeam(botID, teamID);
        }
        [HttpPost]
        public async Task<int> SaveBotAssignment(BotAssignment botAssignment) => await _botAssignmentService.SaveBotAssignment(botAssignment);

        [HttpDelete]
        public async Task DeletetBotAssignment(int botID, int teamID) => await _botAssignmentService.DeletetBotAssignment(botID, teamID);
    }
}