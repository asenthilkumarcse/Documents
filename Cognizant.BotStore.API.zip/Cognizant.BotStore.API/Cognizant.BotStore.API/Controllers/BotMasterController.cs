﻿using Cognizant.BotStore.Core;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.API.Controllers
{
    [Route("api/botmaster")]
    [ApiController]
    public class BotMasterController : ControllerBase
    {
        private readonly IBotMasterService _botMasterService;
        public BotMasterController(IBotMasterService botMasterService)
        {
            _botMasterService = botMasterService;
        }
        [HttpGet("{id}")]
        public async Task<BotMaster> GetBotById(int id) => await _botMasterService.GetBotMasterById(id);

        [HttpGet("GetBotMasterByAccountId")]
        public async Task<List<AccountBot>> GetBotMasterByAccountId(int accountId) => await _botMasterService.GetBotMasterByAccountId(accountId);

        [HttpGet]
        public async Task<List<BotMaster>> GetBots() => await _botMasterService.GetBotMaster();

        [HttpPost]
        public async Task SaveBotDetails(BotMaster botMaster) => await _botMasterService.SaveBotMaster(botMaster);

        [HttpPut]
        public async Task UpdateBotDetails([FromBody] BotUpdateDetails botUpdate)
            => await _botMasterService.UpdateBotMaster(botUpdate);

        [HttpDelete("{id}")]
        public async Task DeletetBotById(int id) => await _botMasterService.DeletetBotById(id);
    }
}