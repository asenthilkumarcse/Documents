﻿using Cognizant.BotStore.Core;
using Cognizant.BotStore.Infrastructure;
using Microsoft.Extensions.DependencyInjection;

namespace Cognizant.BotStore.API
{
    public static class ServiceConfiguration
    {
        public static void AddEfCoreRepository(this IServiceCollection services)
        {
            services.AddScoped(typeof(IGenericEfRepository<>), typeof(GenericEfRepository<>));
            services.AddScoped(typeof(ITeamDetailsRepository), typeof(TeamDetailsRepository));
            services.AddScoped(typeof(IAttributeDetailsRepository), typeof(AttributeDetailsRepository));
            services.AddScoped(typeof(IBotAssignmentRepository), typeof(BotAssignmentRepository));
            services.AddScoped(typeof(IBotAttributeMasterRepository), typeof(BotAttributeMasterRepository));
            services.AddScoped(typeof(IBotIntendMasterRepository), typeof(BotIntendMasterRepository));
            services.AddScoped(typeof(IBotMasterRepository), typeof(BotMasterRepository));
            services.AddScoped(typeof(IBotSkillMasterRepository), typeof(BotSkillMasterRepository));
            services.AddScoped(typeof(IIntendDetailsRepository), typeof(IntendDetailsRepository));
            services.AddScoped(typeof(IAccountRepository), typeof(AccountRepository));
            services.AddScoped(typeof(IBotUserRepository), typeof(BotUserRepository));
            services.AddScoped(typeof(IAccountBotRepository), typeof(AccountBotRepository));
            services.AddScoped(typeof(IALMTypeRepository), typeof(ALMTypeRepository));
            services.AddScoped(typeof(IBotRuleMappingRepository), typeof(BotRuleMappingRepository));
            services.AddScoped(typeof(ICategoryTypeRepository), typeof(CategoryTypeRepository));
            services.AddScoped(typeof(ICategoryTypeValueRepository), typeof(CategoryTypeValueRepository));
            services.AddScoped(typeof(IChannelRepository), typeof(ChannelRepository));
            services.AddScoped(typeof(IConditionTypeRepository), typeof(ConditionTypeRepository));
            services.AddScoped(typeof(IConditionTypeValueRepository), typeof(ConditionTypeValueRepository));
            services.AddScoped(typeof(IRuleDetailRepository), typeof(RuleDetailRepository));
            services.AddScoped(typeof(IRuleMasterRepository), typeof(RuleMasterRepository));
            services.AddScoped(typeof(IRuleTypeRepository), typeof(RuleTypeRepository));
            services.AddScoped(typeof(IRuleChannelRepository), typeof(RuleChannelRepository));
            services.AddScoped(typeof(IAccountBotRuleRepository), typeof(AccountBotRuleRepository));
            services.AddScoped(typeof(IBotEnquiryRepository), typeof(BotEnquiryRepository));
            //services.AddScoped(typeof(IBotImageDetailsRepository), typeof(BotImageDetailsRepository));
        }
        public static void AddEntityServices(this IServiceCollection services)
        {
            services.AddScoped<IAttributeDetailsService, AttributeDetailsService>();
            services.AddScoped<IBotAssignmentService, BotAssignmentService>();
            services.AddScoped<IBotAttributeMasterService, BotAttributeMasterService>();
            services.AddScoped<IBotIntendMasterService, BotIntendMasterService>();
            services.AddScoped<IBotMasterService, BotMasterService>();
            services.AddScoped<IBotSkillMasterService, BotSkillMasterService>();
            services.AddScoped<IIntendDetailsService, IntendDetailsService>();
            services.AddScoped<ITeamDetailsService, TeamDetailsService>();
            services.AddScoped<IAccountService, AccountService>();
            services.AddScoped<IBotUserService, BotUserService>();
            services.AddScoped<IAccountBotService, AccountBotService>();
            services.AddScoped<IALMTypeService, ALMTypeService>();
            services.AddScoped<IBotRuleMappingService, BotRuleMappingService>();
            services.AddScoped<ICategoryTypeService, CategoryTypeService>();
            services.AddScoped<ICategoryTypeValueService, CategoryTypeValueService>();
            services.AddScoped<IChannelService, ChannelService>();
            services.AddScoped<IConditionTypeService, ConditionTypeService>();
            services.AddScoped<IConditionTypeValueService, ConditionTypeValueService>();
            services.AddScoped<IRuleDetailService, RuleDetailService>();
            services.AddScoped<IRuleMasterService, RuleMasterService>();
            services.AddScoped<IRuleTypeService, RuleTypeService>();
            services.AddScoped<IRuleChannelService, RuleChannelService>();
            services.AddScoped<IAccountBotRuleService, AccountBotRuleService>();
            services.AddScoped<IBotEnquiryService, BotEnquiryService>();
            //services.AddScoped<IBotListService, BotListService>();
            //  services.AddScoped<IBotImageDetailsService, BotImageDetailsService>();
        }
    }
}
