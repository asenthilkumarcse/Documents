﻿namespace Cognizant.BotStore.Core
{
    public class BaseResponse
    {
        public int StatusCode { get; set; }
        public string StatusDescription { get; set; }
        public int ID { get; set; }
    }
}
