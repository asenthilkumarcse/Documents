using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class BotEnquiryService : IBotEnquiryService
    {
        private readonly IBotEnquiryRepository _botenquiryRepository;
        public BotEnquiryService(IBotEnquiryRepository botenquiryRepository)
        {
            _botenquiryRepository = botenquiryRepository;
        }
        public async Task<BaseResponse> DeleteBotEnquiryById(int botenquiryId)
        {
            return await _botenquiryRepository.DeleteBotEnquiryById(botenquiryId);
        }
        public async Task<BotEnquiry> GetBotEnquiryById(int botenquiryId)
        {
            return await _botenquiryRepository.GetBotEnquiryById(botenquiryId);
        }
        public async Task<List<BotEnquiry>> GetBotEnquiry()
        {
            return await _botenquiryRepository.GetBotEnquiry();
        }
        public async Task<BaseResponse> SaveBotEnquiry(BotEnquiry botenquiry)
        {
            return await _botenquiryRepository.SaveBotEnquiry(botenquiry);
        }
        public async Task<BaseResponse> UpdateBotEnquiry(BotEnquiry botenquiry)
        {
            return await _botenquiryRepository.UpdateBotEnquiry(botenquiry);
        }
    }
}
