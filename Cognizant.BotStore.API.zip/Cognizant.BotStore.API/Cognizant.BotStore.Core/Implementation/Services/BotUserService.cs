using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class BotUserService : IBotUserService
    {
        private readonly IBotUserRepository _botuserRepository;
        public BotUserService(IBotUserRepository botuserRepository)
        {
            _botuserRepository = botuserRepository;
        }
        public async Task DeleteBotUserById(int botuserId)
        {
            await _botuserRepository.DeleteBotUserById(botuserId);
        }
        public async Task<BotUser> GetBotUserById(int botuserId)
        {
            return await _botuserRepository.GetBotUserById(botuserId);
        }
        public async Task<List<BotUser>> GetBotUser()
        {
            return await _botuserRepository.GetBotUser();
        }
        public async Task<int> SaveBotUser(BotUser botuser)
        {
            return await _botuserRepository.SaveBotUser(botuser);
        }
        public async Task<int> UpdateBotUser(BotUser botuser)
        {
            return await _botuserRepository.UpdateBotUser(botuser);
        }
        public async Task<LoginResponse> ValidateUser(LoginRequest loginRequest)
        {
            return await _botuserRepository.ValidateUser(loginRequest);
        }
        public async Task<string> ChangePassword(ChangePassword changePassword)
        {
            return await _botuserRepository.ChangePassword(changePassword);
        }

        public async Task<ForgetPasswordResponse> ForgetPassword(ForgetPassword forgetPassword)
        {
            return await _botuserRepository.ForgetPassword(forgetPassword);
        }
    }
}
