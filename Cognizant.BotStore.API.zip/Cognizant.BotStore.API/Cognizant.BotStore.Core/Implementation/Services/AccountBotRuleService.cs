using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class AccountBotRuleService : IAccountBotRuleService
    {
        private readonly IAccountBotRuleRepository _accountbotruleRepository;
        public AccountBotRuleService(IAccountBotRuleRepository accountbotruleRepository)
        {
            _accountbotruleRepository = accountbotruleRepository;
        }
        public async Task<BaseResponse> DeleteAccountBotRuleById(int accountbotruleId)
        {
            return await _accountbotruleRepository.DeleteAccountBotRuleById(accountbotruleId);
        }
        public async Task<AccountBotRule> GetAccountBotRuleById(int accountbotruleId)
        {
            return await _accountbotruleRepository.GetAccountBotRuleById(accountbotruleId);
        }
        public async Task<List<AccountBotRule>> GetAccountBotRule()
        {
            return await _accountbotruleRepository.GetAccountBotRule();
        }
        public async Task<BaseResponse> SaveAccountBotRule(AccountBotRule accountbotrule)
        {
            return await _accountbotruleRepository.SaveAccountBotRule(accountbotrule);
        }
        public async Task<BaseResponse> UpdateAccountBotRule(AccountBotRule accountbotrule)
        {
            return await _accountbotruleRepository.UpdateAccountBotRule(accountbotrule);
        }

        public async Task<BaseResponse> BulkSaveAccountBotRule(IList<AccountBotRule> accountbotrule)
        {
            return await _accountbotruleRepository.BulkSaveAccountBotRule(accountbotrule);
        }

        public async Task<BaseResponse> DeleteAccountBotRule(List<AccountBotRule> accountBotRules)
        {
            return await _accountbotruleRepository.DeleteAccountBotRule(accountBotRules);
        }
        public async Task<BaseResponse> DeleteRuleByAccountBotID(int accountID, int botID)
        {
            return await _accountbotruleRepository.DeleteRuleByAccountBotID(accountID, botID);
        }
    }
}
