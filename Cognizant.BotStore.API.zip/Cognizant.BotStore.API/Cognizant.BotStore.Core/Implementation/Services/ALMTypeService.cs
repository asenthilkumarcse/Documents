using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class ALMTypeService : IALMTypeService
    {
        private readonly IALMTypeRepository _almtypeRepository;
        public ALMTypeService(IALMTypeRepository almtypeRepository)
        {
            _almtypeRepository = almtypeRepository;
        }
        public async Task<BaseResponse> DeleteALMTypeById(int almtypeId)
        {
            return await _almtypeRepository.DeleteALMTypeById(almtypeId);
        }
        public async Task<ALMType> GetALMTypeById(int almtypeId)
        {
            return await _almtypeRepository.GetALMTypeById(almtypeId);
        }
        public async Task<List<ALMType>> GetALMType()
        {
            return await _almtypeRepository.GetALMType();
        }
        public async Task<BaseResponse> SaveALMType(ALMType almtype)
        {
            return await _almtypeRepository.SaveALMType(almtype);
        }
        public async Task<BaseResponse> UpdateALMType(ALMType almtype)
        {
            return await _almtypeRepository.UpdateALMType(almtype);
        }
    }
}
