using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class RuleDetailService : IRuleDetailService
    {
        private readonly IRuleDetailRepository _ruledetailRepository;
        public RuleDetailService(IRuleDetailRepository ruledetailRepository)
        {
            _ruledetailRepository = ruledetailRepository;
        }
        public async Task<BaseResponse> DeleteRuleDetailById(int ruledetailId)
        {
            return await _ruledetailRepository.DeleteRuleDetailById(ruledetailId);
        }
        public async Task<RuleDetail> GetRuleDetailById(int ruledetailId)
        {
            return await _ruledetailRepository.GetRuleDetailById(ruledetailId);
        }
        public async Task<List<RuleDetail>> GetRuleDetail()
        {
            return await _ruledetailRepository.GetRuleDetail();
        }
        public async Task<BaseResponse> SaveRuleDetail(RuleDetail ruledetail)
        {
            return await _ruledetailRepository.SaveRuleDetail(ruledetail);
        }
        public async Task<BaseResponse> UpdateRuleDetail(RuleDetail ruledetail)
        {
            return await _ruledetailRepository.UpdateRuleDetail(ruledetail);
        }
    }
}
