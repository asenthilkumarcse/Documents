using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class RuleChannelService : IRuleChannelService
    {
        private readonly IRuleChannelRepository _rulechannelRepository;
        public RuleChannelService(IRuleChannelRepository rulechannelRepository)
        {
            _rulechannelRepository = rulechannelRepository;
        }
        public async Task<BaseResponse> DeleteRuleChannelById(int rulechannelId)
        {
            return await _rulechannelRepository.DeleteRuleChannelById(rulechannelId);
        }
        public async Task<RuleChannel> GetRuleChannelById(int rulechannelId)
        {
            return await _rulechannelRepository.GetRuleChannelById(rulechannelId);
        }
        public async Task<List<RuleChannel>> GetRuleChannel()
        {
            return await _rulechannelRepository.GetRuleChannel();
        }
        public async Task<BaseResponse> SaveRuleChannel(RuleChannel rulechannel)
        {
            return await _rulechannelRepository.SaveRuleChannel(rulechannel);
        }
        public async Task<BaseResponse> UpdateRuleChannel(RuleChannel rulechannel)
        {
            return await _rulechannelRepository.UpdateRuleChannel(rulechannel);
        }
    }
}
