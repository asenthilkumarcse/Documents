﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class IntendDetailsService : IIntendDetailsService
    {
        private readonly IIntendDetailsRepository _intendDetailsRepository;
        public IntendDetailsService(IIntendDetailsRepository intendDetailsRepository)
        {
            _intendDetailsRepository = intendDetailsRepository;
        }

        public async Task<List<IntendDetail>> GetIntendDetails()
        {
            return await _intendDetailsRepository.GetIntendDetails();
        }

        public async Task<int> SaveIntendDetails(IntendDetail intendDetails)
        {
            return await _intendDetailsRepository.SaveIntendDetails(intendDetails);
        }
        public async Task DeleteBotIntentDetailById(int intentDetailId)
        {
            await _intendDetailsRepository.DeleteBotIntentDetailById(intentDetailId);
        }
    }
}
