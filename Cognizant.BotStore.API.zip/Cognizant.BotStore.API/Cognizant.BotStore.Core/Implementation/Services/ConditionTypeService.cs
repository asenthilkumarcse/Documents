using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class ConditionTypeService : IConditionTypeService
    {
        private readonly IConditionTypeRepository _conditiontypeRepository;
        public ConditionTypeService(IConditionTypeRepository conditiontypeRepository)
        {
            _conditiontypeRepository = conditiontypeRepository;
        }
        public async Task<BaseResponse> DeleteConditionTypeById(int conditiontypeId)
        {
            return await _conditiontypeRepository.DeleteConditionTypeById(conditiontypeId);
        }
        public async Task<ConditionType> GetConditionTypeById(int conditiontypeId)
        {
            return await _conditiontypeRepository.GetConditionTypeById(conditiontypeId);
        }
        public async Task<List<ConditionType>> GetConditionType()
        {
            return await _conditiontypeRepository.GetConditionType();
        }
        public async Task<BaseResponse> SaveConditionType(ConditionType conditiontype)
        {
            return await _conditiontypeRepository.SaveConditionType(conditiontype);
        }
        public async Task<BaseResponse> UpdateConditionType(ConditionType conditiontype)
        {
            return await _conditiontypeRepository.UpdateConditionType(conditiontype);
        }
    }
}
