using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class BotRuleMappingService : IBotRuleMappingService
    {
        private readonly IBotRuleMappingRepository _botrulemappingRepository;
        public BotRuleMappingService(IBotRuleMappingRepository botrulemappingRepository)
        {
            _botrulemappingRepository = botrulemappingRepository;
        }
        public async Task<BaseResponse> DeleteBotRuleMappingById(int botrulemappingId)
        {
            return await _botrulemappingRepository.DeleteBotRuleMappingById(botrulemappingId);
        }
        public async Task<BotRuleMapping> GetBotRuleMappingById(int botrulemappingId)
        {
            return await _botrulemappingRepository.GetBotRuleMappingById(botrulemappingId);
        }
        public async Task<List<BotRuleMapping>> GetBotRuleMapping()
        {
            return await _botrulemappingRepository.GetBotRuleMapping();
        }
        public async Task<BaseResponse> SaveBotRuleMapping(BotRuleMapping botrulemapping)
        {
            return await _botrulemappingRepository.SaveBotRuleMapping(botrulemapping);
        }
        public async Task<BaseResponse> UpdateBotRuleMapping(BotRuleMapping botrulemapping)
        {
            return await _botrulemappingRepository.UpdateBotRuleMapping(botrulemapping);
        }
    }
}
