using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class AccountService : IAccountService
    {
        private readonly IAccountRepository _accountRepository;
        public AccountService(IAccountRepository accountRepository)
        {
            _accountRepository = accountRepository;
        }
        public async Task DeleteAccountById(int accountId)
        {
            await _accountRepository.DeleteAccountById(accountId);
        }
        public async Task<Account> GetAccountById(int accountId)
        {
            return await _accountRepository.GetAccountById(accountId);
        }
        public async Task<List<Account>> GetAccount()
        {
            return await _accountRepository.GetAccount();
        }
        public async Task<int> SaveAccount(Account account)
        {
            return await _accountRepository.SaveAccount(account);
        }
        public async Task<int> UpdateAccount(Account account)
        {
            return await _accountRepository.UpdateAccount(account);
        }
    }
}
