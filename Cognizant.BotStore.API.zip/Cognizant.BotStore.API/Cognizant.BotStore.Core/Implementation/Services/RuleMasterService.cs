using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class RuleMasterService : IRuleMasterService
    {
        private readonly IRuleMasterRepository _rulemasterRepository;
        public RuleMasterService(IRuleMasterRepository rulemasterRepository)
        {
            _rulemasterRepository = rulemasterRepository;
        }
        public async Task<BaseResponse> DeleteRuleMasterById(int rulemasterId)
        {
            return await _rulemasterRepository.DeleteRuleMasterById(rulemasterId);
        }
        public async Task<RuleMaster> GetRuleMasterById(int rulemasterId)
        {
            return await _rulemasterRepository.GetRuleMasterById(rulemasterId);
        }
        public async Task<List<RuleMaster>> GetRuleMaster()
        {
            return await _rulemasterRepository.GetRuleMaster();
        }
        public async Task<BaseResponse> SaveRuleMaster(RuleMaster rulemaster)
        {
            return await _rulemasterRepository.SaveRuleMaster(rulemaster);
        }
        public async Task<BaseResponse> UpdateRuleMaster(RuleMaster rulemaster)
        {
            return await _rulemasterRepository.UpdateRuleMaster(rulemaster);
        }
        public async Task<List<RuleMaster>> GetRuleMasterByBotID(int botMasterID)
        {
            return await _rulemasterRepository.GetRuleMasterByBotID(botMasterID);
        }

        public async Task<List<RuleMasterModel>> GetRuleAccountBotByBotID(int botMasterID, int accountID)
        {
            return await _rulemasterRepository.GetRuleAccountBotByBotID(botMasterID, accountID);
        }
    }
}
