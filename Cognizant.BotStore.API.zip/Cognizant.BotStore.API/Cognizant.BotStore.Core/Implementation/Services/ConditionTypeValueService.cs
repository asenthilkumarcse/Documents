using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class ConditionTypeValueService : IConditionTypeValueService
    {
        private readonly IConditionTypeValueRepository _conditiontypevalueRepository;
        public ConditionTypeValueService(IConditionTypeValueRepository conditiontypevalueRepository)
        {
            _conditiontypevalueRepository = conditiontypevalueRepository;
        }
        public async Task<BaseResponse> DeleteConditionTypeValueById(int conditiontypevalueId)
        {
            return await _conditiontypevalueRepository.DeleteConditionTypeValueById(conditiontypevalueId);
        }
        public async Task<ConditionTypeValue> GetConditionTypeValueById(int conditiontypevalueId)
        {
            return await _conditiontypevalueRepository.GetConditionTypeValueById(conditiontypevalueId);
        }
        public async Task<List<ConditionTypeValue>> GetConditionTypeValue()
        {
            return await _conditiontypevalueRepository.GetConditionTypeValue();
        }
        public async Task<BaseResponse> SaveConditionTypeValue(ConditionTypeValue conditiontypevalue)
        {
            return await _conditiontypevalueRepository.SaveConditionTypeValue(conditiontypevalue);
        }
        public async Task<BaseResponse> UpdateConditionTypeValue(ConditionTypeValue conditiontypevalue)
        {
            return await _conditiontypevalueRepository.UpdateConditionTypeValue(conditiontypevalue);
        }
    }
}
