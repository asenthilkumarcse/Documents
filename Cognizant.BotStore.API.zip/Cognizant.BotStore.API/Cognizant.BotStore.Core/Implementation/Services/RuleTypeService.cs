using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class RuleTypeService : IRuleTypeService
    {
        private readonly IRuleTypeRepository _ruletypeRepository;
        public RuleTypeService(IRuleTypeRepository ruletypeRepository)
        {
            _ruletypeRepository = ruletypeRepository;
        }
        public async Task<BaseResponse> DeleteRuleTypeById(int ruletypeId)
        {
            return await _ruletypeRepository.DeleteRuleTypeById(ruletypeId);
        }
        public async Task<RuleType> GetRuleTypeById(int ruletypeId)
        {
            return await _ruletypeRepository.GetRuleTypeById(ruletypeId);
        }
        public async Task<List<RuleType>> GetRuleType()
        {
            return await _ruletypeRepository.GetRuleType();
        }
        public async Task<BaseResponse> SaveRuleType(RuleType ruletype)
        {
            return await _ruletypeRepository.SaveRuleType(ruletype);
        }
        public async Task<BaseResponse> UpdateRuleType(RuleType ruletype)
        {
            return await _ruletypeRepository.UpdateRuleType(ruletype);
        }
    }
}
