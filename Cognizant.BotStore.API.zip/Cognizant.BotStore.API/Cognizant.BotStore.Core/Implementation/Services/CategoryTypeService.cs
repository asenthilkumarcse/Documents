using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class CategoryTypeService : ICategoryTypeService
    {
        private readonly ICategoryTypeRepository _categorytypeRepository;
        public CategoryTypeService(ICategoryTypeRepository categorytypeRepository)
        {
            _categorytypeRepository = categorytypeRepository;
        }
        public async Task<BaseResponse> DeleteCategoryTypeById(int categorytypeId)
        {
            return await _categorytypeRepository.DeleteCategoryTypeById(categorytypeId);
        }
        public async Task<CategoryType> GetCategoryTypeById(int categorytypeId)
        {
            return await _categorytypeRepository.GetCategoryTypeById(categorytypeId);
        }
        public async Task<List<CategoryType>> GetCategoryType()
        {
            return await _categorytypeRepository.GetCategoryType();
        }
        public async Task<BaseResponse> SaveCategoryType(CategoryType categorytype)
        {
            return await _categorytypeRepository.SaveCategoryType(categorytype);
        }
        public async Task<BaseResponse> UpdateCategoryType(CategoryType categorytype)
        {
            return await _categorytypeRepository.UpdateCategoryType(categorytype);
        }
    }
}
