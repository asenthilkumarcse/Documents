using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class CategoryTypeValueService : ICategoryTypeValueService
    {
        private readonly ICategoryTypeValueRepository _categorytypevalueRepository;
        public CategoryTypeValueService(ICategoryTypeValueRepository categorytypevalueRepository)
        {
            _categorytypevalueRepository = categorytypevalueRepository;
        }
        public async Task<BaseResponse> DeleteCategoryTypeValueById(int categorytypevalueId)
        {
            return await _categorytypevalueRepository.DeleteCategoryTypeValueById(categorytypevalueId);
        }
        public async Task<CategoryTypeValue> GetCategoryTypeValueById(int categorytypevalueId)
        {
            return await _categorytypevalueRepository.GetCategoryTypeValueById(categorytypevalueId);
        }
        public async Task<List<CategoryTypeValue>> GetCategoryTypeValue()
        {
            return await _categorytypevalueRepository.GetCategoryTypeValue();
        }
        public async Task<BaseResponse> SaveCategoryTypeValue(CategoryTypeValue categorytypevalue)
        {
            return await _categorytypevalueRepository.SaveCategoryTypeValue(categorytypevalue);
        }
        public async Task<BaseResponse> UpdateCategoryTypeValue(CategoryTypeValue categorytypevalue)
        {
            return await _categorytypevalueRepository.UpdateCategoryTypeValue(categorytypevalue);
        }
    }
}
