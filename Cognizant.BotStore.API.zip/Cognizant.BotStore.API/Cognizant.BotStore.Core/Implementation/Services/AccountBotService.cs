using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class AccountBotService : IAccountBotService
    {
        private readonly IAccountBotRepository _accountbotRepository;
        public AccountBotService(IAccountBotRepository accountbotRepository)
        {
            _accountbotRepository = accountbotRepository;
        }
        public async Task DeleteAccountBotById(int accountId, int botId)
        {
            await _accountbotRepository.DeleteAccountBotById(accountId, botId);
        }
        public async Task<AccountBot> GetAccountBotById(int accountbotId)
        {
            return await _accountbotRepository.GetAccountBotById(accountbotId);
        }
        public async Task<List<AccountBotDetails>> GetAccountBot()
        {
            return await _accountbotRepository.GetAccountBot();
        }
        public async Task<int> SaveAccountBot(AccountBot accountbot)
        {
            return await _accountbotRepository.SaveAccountBot(accountbot);
        }
        public async Task<int> UpdateAccountBot(AccountBot accountbot)
        {
            return await _accountbotRepository.UpdateAccountBot(accountbot);
        }

        public async Task<List<AccountBotDetails>> GettBotByAccountId(int accountId)
        {
            return await _accountbotRepository.GettBotByAccountId(accountId);
        }

        public async Task DeleteAccount(int accountId, int BotId)
        {
            await _accountbotRepository.DeleteAccount(accountId, BotId);
        }
    }
}
