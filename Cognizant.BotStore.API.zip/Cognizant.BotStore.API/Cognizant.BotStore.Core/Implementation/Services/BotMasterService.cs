﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class BotMasterService : IBotMasterService
    {
        private readonly IBotMasterRepository _botMasterRepository;
        private readonly IBotSkillMasterRepository _botSkillMasterRepository;
        private readonly IBotAttributeMasterRepository _botAttributeMasterRepository;
        private readonly IBotIntendMasterRepository _botIntendMasterRepository;
        private readonly IRuleChannelRepository _ruleChannelRepository;
        private readonly IRuleMasterRepository _ruleMasterRepository;
        public BotMasterService(
                IBotMasterRepository botMasterRepository
                , IBotSkillMasterRepository botSkillMasterRepository
                , IBotAttributeMasterRepository botAttributeMasterRepository
                , IBotIntendMasterRepository botIntendMasterRepository
                , IRuleChannelRepository ruleChannelRepository
                , IRuleMasterRepository ruleMasterRepository
            )
        {
            _botMasterRepository = botMasterRepository;
            _botSkillMasterRepository = botSkillMasterRepository;
            _botAttributeMasterRepository = botAttributeMasterRepository;
            _botIntendMasterRepository = botIntendMasterRepository;
            _ruleChannelRepository = ruleChannelRepository;
            _ruleMasterRepository = ruleMasterRepository;
        }

        public async Task<int> DeletetBotById(int botId)
        {
            return await _botMasterRepository.DeletetBotById(botId);
        }

        public async Task<List<BotMaster>> GetBotMaster()
        {
            return await _botMasterRepository.GetBotMaster();
        }
        public async Task<List<AccountBot>> GetBotMasterByAccountId(int accountId)
        {
            return await _botMasterRepository.GetBotMasterByAccountId(accountId);
        }
        public async Task<BotMaster> GetBotMasterById(int botId)
        {
            return await _botMasterRepository.GetBotMasterById(botId);
        }

        public async Task<int> SaveBotMaster(BotMaster botMaster)
        {
            return await _botMasterRepository.SaveBotMaster(botMaster);
        }

        public async Task<int> UpdateBotMaster(BotUpdateDetails botUpdate)
        {
            if (botUpdate.DeleteAttributeMaster != null && botUpdate.DeleteAttributeMaster.Count > 0)
            {
                foreach (DeleteMaster deleteMaster in botUpdate.DeleteAttributeMaster)
                    await _botAttributeMasterRepository.DeleteBotAttributeMasterById(deleteMaster.DeleteID);
            }

            if (botUpdate.DeleteIntendMaster != null && botUpdate.DeleteIntendMaster.Count > 0)
            {
                foreach (DeleteMaster deleteMaster in botUpdate.DeleteIntendMaster)
                    await _botIntendMasterRepository.DeleteBotIntendMasterById(deleteMaster.DeleteID);
            }

            if (botUpdate.DeleteSkillMaster != null && botUpdate.DeleteSkillMaster.Count > 0)
            {
                foreach (DeleteMaster deleteMaster in botUpdate.DeleteSkillMaster)
                    await _botSkillMasterRepository.DeleteBotSkillMasterById(deleteMaster.DeleteID);
            }

            if (botUpdate.DeleteChannel != null && botUpdate.DeleteChannel.Count > 0)
            {
                foreach (DeleteMaster deleteMaster in botUpdate.DeleteChannel)
                    await _ruleChannelRepository.DeleteRuleChannelById(deleteMaster.DeleteID);
            }

            if (botUpdate.DeleteRuleMaster != null && botUpdate.DeleteRuleMaster.Count > 0)
            {
                foreach (DeleteMaster deleteMaster in botUpdate.DeleteRuleMaster)
                    await _ruleMasterRepository.DeleteRuleMasterById(deleteMaster.DeleteID);
            }

            return await _botMasterRepository.UpdateBotMaster(botUpdate.BotMaster);
        }

    }
}
