﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class TeamDetailsService : ITeamDetailsService
    {
        private readonly ITeamDetailsRepository _teamDetailsRepository;
        public TeamDetailsService(ITeamDetailsRepository teamDetailsRepository)
        {
            _teamDetailsRepository = teamDetailsRepository;
        }

        public async Task<List<TeamDetail>> GetTeamDetails()
        {
            return await _teamDetailsRepository.GetTeamDetails();
        }
        public async Task<List<TeamDetail>> GetTeamDetailsByAccountID(int accountID)
        {
            return await _teamDetailsRepository.GetTeamDetailsByAccountID(accountID);
        }

        public async Task<int> SaveTeamDetails(TeamDetail teamDetails)
        {
            return await _teamDetailsRepository.SaveTeamDetails(teamDetails);
        }
        public async Task DeleteTeamDetailById(int teamDetailId)
        {
            await _teamDetailsRepository.DeleteTeamDetailById(teamDetailId);
        }
        public async Task<TeamDetail> GetTeamDetailById(int teamDetailId)
        {
            return await _teamDetailsRepository.GetTeamDetailById(teamDetailId);
        }
        public async Task<int> UpdateTeamDetail(TeamDetail teamDetail)
        {
            return await _teamDetailsRepository.UpdateTeamDetail(teamDetail);
        }
        public async Task<List<TeamDetail>> GetAssignedTeamDetailsByBotId(int botId)
        {
            return await _teamDetailsRepository.GetAssignedTeamDetailsByBotId(botId);
        }
        public async Task<List<TeamDetail>> GetAssignedTeamDetailsByAccountID(int botId, int accountID)
        {
            return await _teamDetailsRepository.GetAssignedTeamDetailsByAccountID(botId, accountID);
        }
        public async Task<List<TeamDetail>> GetUnAssignedTeamDetailsForBot(int botId)
        {
            return await _teamDetailsRepository.GetUnAssignedTeamDetailsForBot(botId);
        }
        public async Task<List<TeamDetail>> GetUnAssignedTeamDetailsByAccountID(int botId, int accountID)
        {
            return await _teamDetailsRepository.GetUnAssignedTeamDetailsByAccountID(botId, accountID);
        }
    }
}
