using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public class ChannelService : IChannelService
    {
        private readonly IChannelRepository _channelRepository;
        public ChannelService(IChannelRepository channelRepository)
        {
            _channelRepository = channelRepository;
        }
        public async Task<BaseResponse> DeleteChannelById(int channelId)
        {
            return await _channelRepository.DeleteChannelById(channelId);
        }
        public async Task<Channel> GetChannelById(int channelId)
        {
            return await _channelRepository.GetChannelById(channelId);
        }
        public async Task<List<Channel>> GetChannel()
        {
            return await _channelRepository.GetChannel();
        }
        public async Task<BaseResponse> SaveChannel(Channel channel)
        {
            return await _channelRepository.SaveChannel(channel);
        }
        public async Task<BaseResponse> UpdateChannel(Channel channel)
        {
            return await _channelRepository.UpdateChannel(channel);
        }
    }
}
