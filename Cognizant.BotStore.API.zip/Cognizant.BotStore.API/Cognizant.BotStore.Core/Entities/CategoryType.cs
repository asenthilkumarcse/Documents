﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class CategoryType : BaseEntity
    {
        [Key]
        public int CategoryTypeID { get; set; }
        public string CategoryName { get; set; }
    }
}
