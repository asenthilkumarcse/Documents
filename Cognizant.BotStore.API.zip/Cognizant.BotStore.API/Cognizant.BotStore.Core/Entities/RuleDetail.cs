﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class RuleDetail
    {
        [Key]
        public int RuleDetailID { get; set; }
        public int RuleMasterID { get; set; }
        public int CategoryTypeID { get; set; }
        public string CategoryOperator { get; set; }
        public int CategoryTypeValue { get; set; }
        public string StartCondition { get; set; }
        public int ConditionTypeID { get; set; }
        public string ConditionOperator { get; set; }
        public string ConditionValue { get; set; }
        public string EndCondition { get; set; }
    }
}
