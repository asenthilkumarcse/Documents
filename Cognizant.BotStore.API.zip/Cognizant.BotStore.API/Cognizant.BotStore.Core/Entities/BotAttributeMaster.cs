﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotAttributeMaster
    {
        [Key]
        public int BotAttributeMasterID { get; set; }
        public string AttributeName { get; set; }
        public int BotMasterID { get; set; }
        public bool IsCustomAttribute { get; set; }
        public List<AttributeDetail> AttributeDetails { get; set; }
    }
}
