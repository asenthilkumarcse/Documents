﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotAssignmentDetail: BaseEntity
    {
        [Key]
        public int BotAssignmentID { get; set; }
        public int BotMasterID { get; set; }
        public byte Status { get; set; }
        public int TeamDetailID { get; set; }
        public BotMaster BotMaster { get; set; }
        //public BotAssignment botAssignment { get; set; }
        public List<AttributeDetail> AttributeDetails { get; set; }
        public List<IntendDetail> IntendDetails { get; set; }

    }
}
