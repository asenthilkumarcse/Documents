﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class RuleType : BaseEntity
    {
        [Key]
        public int RuleTypeID { get; set; }
        public string RuleTypeName { get; set; }
    }
}
