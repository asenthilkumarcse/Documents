﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class ConditionTypeValue:BaseEntity
    {
        [Key]
        public int ConditionTypeValueID { get; set; }
        public string Description { get; set; }
    }
}
