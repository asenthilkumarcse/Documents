﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class Account : BaseEntity
    {
        [Key]
        public int AccountID { get; set; }
        public string AccountName { get; set; }
        public bool? Active { get; set; }
    }
}
