﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class AttributeDetail
    {
        [Key]
        public int AttributeDetailID { get; set; }
        public int BotAssignmentID { get; set; }
        public int BotAttributeMasterID { get; set; }
        public string AttributeValue { get; set; }
    }
}
