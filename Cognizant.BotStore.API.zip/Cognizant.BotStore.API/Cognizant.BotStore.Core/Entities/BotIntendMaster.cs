﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotIntendMaster
    {
        [Key]
        public int BotIntendMasterID { get; set; }
        public string IntendName { get; set; }
        public int BotMasterID { get; set; }
        public bool IsCustomIntend { get; set; }
        public List<IntendDetail> IntendDetails { get; set; }
    }
}
