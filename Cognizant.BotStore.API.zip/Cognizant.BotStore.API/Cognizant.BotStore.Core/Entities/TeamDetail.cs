﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class TeamDetail: BaseEntity
    {
        [Key]
        public int TeamDetailID { get; set; }
        public string TeamName { get; set; }
        public bool? Active { get; set; }
        public int? AccountID { get; set; }
        public int? ALMTypeID { get; set; }
    }
}
