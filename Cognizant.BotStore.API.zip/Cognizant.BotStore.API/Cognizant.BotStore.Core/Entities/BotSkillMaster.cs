﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotSkillMaster
    {
        [Key]
        public int BotSkillMasterID { get; set; }
        public string SkillName { get; set; }
        public int BotMasterID { get; set; }
    }
}
