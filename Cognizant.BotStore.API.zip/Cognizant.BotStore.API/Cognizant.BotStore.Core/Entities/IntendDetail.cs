﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class IntendDetail
    {
        [Key]
        public int IntendDetailID { get; set; }
        public int BotAssignmentID { get; set; }
        public int BotIntendMasterID { get; set; }
        public string IntendValue { get; set; }
    }
}
