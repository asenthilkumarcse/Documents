﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Cognizant.BotStore.Core
{
    public class RuleMaster : BaseEntity
    {
        [Key]
        public int RuleMasterID { get; set; }
        public string RuleName { get; set; }
        [ForeignKey("RuleTypeID")]
        public int RuleTypeID { get; set; }
        public int BotMasterID { get; set; }
        public string RuleExpression { get; set; }
        public bool? IsBotStore { get; set; }
        public RuleType RuleType { get; set; }
        public List<RuleChannel> RuleChannel { get; set; }
    }
}
