﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Cognizant.BotStore.Core
{
    public class RuleChannel
    {
        [Key]
        public int RuleChannelID { get; set; }
        public int RuleMasterID { get; set; }
        [ForeignKey("RuleTypeID")]
        public int ChannelID { get; set; }
        public Channel Channel { get; set; }
    }
}

