﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class ConditionType : BaseEntity
    {
        [Key]
        public int ConditionTypeID { get; set; }
        public string ConditionTypeName { get; set; }
    }
}
