﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class AccountBot : BaseEntity
    {
        [Key]
        public int AccountBotID { get; set; }
        public int AccountID { get; set; }
        public int BotMasterID { get; set; }
        public BotMaster BotMaster { get; set; }
    }
}
