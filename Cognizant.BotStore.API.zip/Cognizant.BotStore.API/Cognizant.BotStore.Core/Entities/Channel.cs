﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public  class Channel:BaseEntity
    {
        [Key]
        public int ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
}
