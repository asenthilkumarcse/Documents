﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class ALMType:BaseEntity
    {
        [Key]
        public int ALMTypeID { get; set; }
        public string ALMName { get; set; }
    }
}
