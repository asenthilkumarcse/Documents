﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotRuleMapping
    {
        [Key]
        public int BotRuleMappingID { get; set; }
        public int BotAssignmentID { get; set; }
        public int RuleMasterID { get; set; }
        public int TeamDetailID { get; set; }
        public BotAssignment BotAssignment { get; set; }
        public RuleMaster RuleMaster { get; set; }
        public TeamDetail TeamDetail{ get; set; }
    }
}
