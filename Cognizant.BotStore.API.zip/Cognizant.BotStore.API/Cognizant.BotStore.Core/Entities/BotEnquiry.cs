﻿using System.ComponentModel.DataAnnotations;
using System;

namespace Cognizant.BotStore.Core
{
    public class BotEnquiry
    {
        [Key]
        public int BotEnquiryID { get; set; }
        public string ContactName { get; set; }
        public string ContactNumber { get; set; }
        public string ContactEmail { get; set; }
        public string TimeZone { get; set; }
        public DateTime EnquiryTime { get; set; }
        public int BotID { get; set; }
        public string BotName { get; set; }
    }
}
