﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class BotMaster : BaseEntity
    {
        [Key]
        public int BotMasterID { get; set; }
        public string BotName { get; set; }
        public byte BotStatus { get; set; }
        public string BotImageName { get; set; }
        public bool IsRuleEnabled { get; set; }
        public List<BotSkillMaster> BotSkillMasters { get; set; }
        public List<BotAttributeMaster> BotAttributeMasters { get; set; }
        public List<BotIntendMaster> BotIntendMasters { get; set; }
        public List<BotAssignment> BotAssignments { get; set; }
        public List<RuleMaster> RuleMaster { get; set; }
    }
}
