﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class AccountBotRule : BaseEntity
    {
        [Key]
        public int AccountBotRuleID { get; set; }
        public int AccountID { get; set; }
        public int BotMasterID { get; set; }
        public int RuleMasterID { get; set; }
    }
}
