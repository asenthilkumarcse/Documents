﻿using System.ComponentModel.DataAnnotations;

namespace Cognizant.BotStore.Core
{
    public class CategoryTypeValue : BaseEntity
    {
        [Key]
        public int CategoryTypeValueID { get; set; }
        public string Description { get; set; }
    }
}
