﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IAttributeDetailsRepository
    {
        Task<List<AttributeDetail>> GetAttributeDetails();
        Task<int> SaveAttributeDetails(AttributeDetail attributeDetails);
        Task DeleteBotAttributeDetailsById(int attributeDetailsId);
    }
}
