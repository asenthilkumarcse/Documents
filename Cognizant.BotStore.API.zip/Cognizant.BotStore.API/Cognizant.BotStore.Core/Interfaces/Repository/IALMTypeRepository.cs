using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IALMTypeRepository
    {
        Task<List<ALMType>> GetALMType();
        Task<BaseResponse> SaveALMType(ALMType almtype);
        Task<BaseResponse> UpdateALMType(ALMType almtype);
        Task<ALMType> GetALMTypeById(int almtypeId);
        Task<BaseResponse> DeleteALMTypeById(int almtypeId);
    }
}
