using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IRuleChannelRepository
    {
        Task<List<RuleChannel>> GetRuleChannel();
        Task<BaseResponse> SaveRuleChannel(RuleChannel rulechannel);
        Task<BaseResponse> UpdateRuleChannel(RuleChannel rulechannel);
        Task<RuleChannel> GetRuleChannelById(int rulechannelId);
        Task<BaseResponse> DeleteRuleChannelById(int rulechannelId);
    }
}
