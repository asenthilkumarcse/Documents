﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotMasterRepository
    {
        Task<List<BotMaster>> GetBotMaster();
        Task<List<AccountBot>> GetBotMasterByAccountId(int accountId);
        Task<BotMaster> GetBotMasterById(int botId);
        Task<int> SaveBotMaster(BotMaster botMaster);
        Task<int> UpdateBotMaster(BotMaster botMaster);
        Task<int> DeletetBotById(int botId);
    }
}
