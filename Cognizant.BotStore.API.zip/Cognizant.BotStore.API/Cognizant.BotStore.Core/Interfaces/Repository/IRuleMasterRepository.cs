using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IRuleMasterRepository
    {
        Task<List<RuleMaster>> GetRuleMaster();
        Task<BaseResponse> SaveRuleMaster(RuleMaster rulemaster);
        Task<BaseResponse> UpdateRuleMaster(RuleMaster rulemaster);
        Task<RuleMaster> GetRuleMasterById(int rulemasterId);
        Task<BaseResponse> DeleteRuleMasterById(int rulemasterId);
        Task<List<RuleMaster>> GetRuleMasterByBotID(int botMasterID);
        Task<List<RuleMasterModel>> GetRuleAccountBotByBotID(int botMasterID, int accountID);
    }
}
