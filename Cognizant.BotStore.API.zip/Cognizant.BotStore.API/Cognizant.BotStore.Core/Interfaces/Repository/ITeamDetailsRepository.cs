﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface ITeamDetailsRepository
    {
        Task<List<TeamDetail>> GetTeamDetails();
        Task<List<TeamDetail>> GetTeamDetailsByAccountID(int accountID);
        Task<int> SaveTeamDetails(TeamDetail teamDetails);
        Task<int> UpdateTeamDetail(TeamDetail teamDetail);
        Task<TeamDetail> GetTeamDetailById(int teamDetailId);
        Task DeleteTeamDetailById(int teamDetailId);
        Task<List<TeamDetail>> GetAssignedTeamDetailsByBotId(int botId);
        Task<List<TeamDetail>> GetAssignedTeamDetailsByAccountID(int botId, int accountID);
        Task<List<TeamDetail>> GetUnAssignedTeamDetailsForBot(int botId);
        Task<List<TeamDetail>> GetUnAssignedTeamDetailsByAccountID(int botId, int accountID);
    }
}
