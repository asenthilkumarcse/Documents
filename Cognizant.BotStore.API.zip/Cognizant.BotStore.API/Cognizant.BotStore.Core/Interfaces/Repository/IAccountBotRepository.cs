using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IAccountBotRepository
    {
        Task<List<AccountBotDetails>> GetAccountBot();
        Task<int> SaveAccountBot(AccountBot accountbot);
        Task<int> UpdateAccountBot(AccountBot accountbot);
        Task<AccountBot> GetAccountBotById(int accountbotId);
        Task<List<AccountBotDetails>> GettBotByAccountId(int accountId);
        Task DeleteAccountBotById(int accountId, int botId);
        Task DeleteAccount(int accountId, int BotId);
    }
}
