using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotEnquiryRepository
    {
        Task<List<BotEnquiry>> GetBotEnquiry();
        Task<BaseResponse> SaveBotEnquiry(BotEnquiry botenquiry);
        Task<BaseResponse> UpdateBotEnquiry(BotEnquiry botenquiry);
        Task<BotEnquiry> GetBotEnquiryById(int botenquiryId);
        Task<BaseResponse> DeleteBotEnquiryById(int botenquiryId);
    }
}
