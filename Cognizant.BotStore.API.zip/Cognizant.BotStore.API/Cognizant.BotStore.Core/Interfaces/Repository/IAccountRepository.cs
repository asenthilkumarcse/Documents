using Cognizant.BotStore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IAccountRepository
    {
        Task<List<Account>> GetAccount();
        Task<int> SaveAccount(Account account);
        Task<int> UpdateAccount(Account account);
        Task<Account> GetAccountById(int accountId);
        Task DeleteAccountById(int accountId);
    }
}
