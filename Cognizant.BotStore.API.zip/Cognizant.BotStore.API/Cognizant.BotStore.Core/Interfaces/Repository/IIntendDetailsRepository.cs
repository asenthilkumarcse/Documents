﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IIntendDetailsRepository
    {
        Task<List<IntendDetail>> GetIntendDetails();
        Task<int> SaveIntendDetails(IntendDetail intendDetails);
        Task DeleteBotIntentDetailById(int intentDetailId);
    }
}
