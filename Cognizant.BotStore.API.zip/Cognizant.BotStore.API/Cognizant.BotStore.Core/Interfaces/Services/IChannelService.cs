using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IChannelService
    {
        Task<List<Channel>> GetChannel();
        Task<BaseResponse> SaveChannel(Channel channel);
        Task<BaseResponse> UpdateChannel(Channel channel);
        Task<Channel> GetChannelById(int channelId);
        Task<BaseResponse> DeleteChannelById(int channelId);
    }
}
