using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IAccountBotRuleService
    {
        Task<List<AccountBotRule>> GetAccountBotRule();
        Task<BaseResponse> SaveAccountBotRule(AccountBotRule accountbotrule);
        Task<BaseResponse> UpdateAccountBotRule(AccountBotRule accountbotrule);
        Task<AccountBotRule> GetAccountBotRuleById(int accountbotruleId);
        Task<BaseResponse> DeleteAccountBotRuleById(int accountbotruleId);
        Task<BaseResponse> BulkSaveAccountBotRule(IList<AccountBotRule> accountbotrule);
        Task<BaseResponse> DeleteAccountBotRule(List<AccountBotRule> accountBotRules);
        Task<BaseResponse> DeleteRuleByAccountBotID(int accountID, int botID);
    }
}
