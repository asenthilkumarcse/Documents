using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IRuleMasterService
    {
        Task<List<RuleMaster>> GetRuleMaster();
        Task<BaseResponse> SaveRuleMaster(RuleMaster rulemaster);
        Task<BaseResponse> UpdateRuleMaster(RuleMaster rulemaster);
        Task<RuleMaster> GetRuleMasterById(int rulemasterId);
        Task<List<RuleMaster>> GetRuleMasterByBotID(int botMasterID);
        Task<BaseResponse> DeleteRuleMasterById(int rulemasterId);
        Task<List<RuleMasterModel>> GetRuleAccountBotByBotID(int botMasterID, int accountID);
    }
}
