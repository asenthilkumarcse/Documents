using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface ICategoryTypeValueService
    {
        Task<List<CategoryTypeValue>> GetCategoryTypeValue();
        Task<BaseResponse> SaveCategoryTypeValue(CategoryTypeValue categorytypevalue);
        Task<BaseResponse> UpdateCategoryTypeValue(CategoryTypeValue categorytypevalue);
        Task<CategoryTypeValue> GetCategoryTypeValueById(int categorytypevalueId);
        Task<BaseResponse> DeleteCategoryTypeValueById(int categorytypevalueId);
    }
}
