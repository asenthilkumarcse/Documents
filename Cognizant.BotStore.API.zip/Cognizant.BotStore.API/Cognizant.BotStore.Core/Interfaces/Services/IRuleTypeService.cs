using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IRuleTypeService
    {
        Task<List<RuleType>> GetRuleType();
        Task<BaseResponse> SaveRuleType(RuleType ruletype);
        Task<BaseResponse> UpdateRuleType(RuleType ruletype);
        Task<RuleType> GetRuleTypeById(int ruletypeId);
        Task<BaseResponse> DeleteRuleTypeById(int ruletypeId);
    }
}
