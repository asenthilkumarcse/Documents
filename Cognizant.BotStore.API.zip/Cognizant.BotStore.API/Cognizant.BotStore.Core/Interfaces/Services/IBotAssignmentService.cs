﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotAssignmentService
    {
        Task<List<BotAssignment>> GetBotAssignment();
        Task<List<BotAssignment>> GetBotAssignmentByBotID(int botID);
        Task<BotAssignment> GetBotAssignmentByTeam(int botID, int teamID);
        Task<int> SaveBotAssignment(BotAssignment botAssignment);
        Task<int> DeletetBotAssignment(int botID, int teamID);
    }
}
