using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IRuleDetailService
    {
        Task<List<RuleDetail>> GetRuleDetail();
        Task<BaseResponse> SaveRuleDetail(RuleDetail ruledetail);
        Task<BaseResponse> UpdateRuleDetail(RuleDetail ruledetail);
        Task<RuleDetail> GetRuleDetailById(int ruledetailId);
        Task<BaseResponse> DeleteRuleDetailById(int ruledetailId);
    }
}
