using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotUserService
    {
        Task<List<BotUser>> GetBotUser();
        Task<int> SaveBotUser(BotUser botuser);
        Task<int> UpdateBotUser(BotUser botuser);
        Task<BotUser> GetBotUserById(int botuserId);
        Task DeleteBotUserById(int botuserId);
        Task<LoginResponse> ValidateUser(LoginRequest loginRequest);
        Task<string> ChangePassword(ChangePassword changePassword);
        Task<ForgetPasswordResponse> ForgetPassword(ForgetPassword forgetPassword);
    }
}
