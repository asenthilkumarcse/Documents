using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IConditionTypeService
    {
        Task<List<ConditionType>> GetConditionType();
        Task<BaseResponse> SaveConditionType(ConditionType conditiontype);
        Task<BaseResponse> UpdateConditionType(ConditionType conditiontype);
        Task<ConditionType> GetConditionTypeById(int conditiontypeId);
        Task<BaseResponse> DeleteConditionTypeById(int conditiontypeId);
    }
}
