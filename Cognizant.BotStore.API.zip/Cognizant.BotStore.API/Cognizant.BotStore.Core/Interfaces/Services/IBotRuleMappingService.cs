using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotRuleMappingService
    {
        Task<List<BotRuleMapping>> GetBotRuleMapping();
        Task<BaseResponse> SaveBotRuleMapping(BotRuleMapping botrulemapping);
        Task<BaseResponse> UpdateBotRuleMapping(BotRuleMapping botrulemapping);
        Task<BotRuleMapping> GetBotRuleMappingById(int botrulemappingId);
        Task<BaseResponse> DeleteBotRuleMappingById(int botrulemappingId);
    }
}
