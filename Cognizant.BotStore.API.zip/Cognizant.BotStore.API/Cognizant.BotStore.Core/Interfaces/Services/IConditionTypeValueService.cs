using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IConditionTypeValueService
    {
        Task<List<ConditionTypeValue>> GetConditionTypeValue();
        Task<BaseResponse> SaveConditionTypeValue(ConditionTypeValue conditiontypevalue);
        Task<BaseResponse> UpdateConditionTypeValue(ConditionTypeValue conditiontypevalue);
        Task<ConditionTypeValue> GetConditionTypeValueById(int conditiontypevalueId);
        Task<BaseResponse> DeleteConditionTypeValueById(int conditiontypevalueId);
    }
}
