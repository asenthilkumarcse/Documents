using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface ICategoryTypeService
    {
        Task<List<CategoryType>> GetCategoryType();
        Task<BaseResponse> SaveCategoryType(CategoryType categorytype);
        Task<BaseResponse> UpdateCategoryType(CategoryType categorytype);
        Task<CategoryType> GetCategoryTypeById(int categorytypeId);
        Task<BaseResponse> DeleteCategoryTypeById(int categorytypeId);
    }
}
