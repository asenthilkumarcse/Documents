﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Cognizant.BotStore.Core
{
    public interface IBotMasterService
    {
        Task<List<BotMaster>> GetBotMaster();
        Task<List<AccountBot>> GetBotMasterByAccountId(int accountId);
        Task<int> SaveBotMaster(BotMaster botMaster);
        Task<int> UpdateBotMaster(BotUpdateDetails botMaster);
        Task<BotMaster> GetBotMasterById(int botId);
        Task<int> DeletetBotById(int botId);
    }
}
