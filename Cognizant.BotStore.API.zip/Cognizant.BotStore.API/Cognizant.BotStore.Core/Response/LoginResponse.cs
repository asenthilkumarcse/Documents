﻿namespace Cognizant.BotStore.Core
{
    public class LoginResponse
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public int AccountID { get; set; }
        public string ErrorDescription { get; set; }
        public bool? IsClient { get; set; }
    }
}
