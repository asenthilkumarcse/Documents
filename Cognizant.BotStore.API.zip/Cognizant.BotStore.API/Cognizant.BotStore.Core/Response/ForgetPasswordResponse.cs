﻿namespace Cognizant.BotStore.Core
{
    public class ForgetPasswordResponse
    {
        public string Email { get; set; }
        public string Status { get; set; }
        public int StatusCode { get; set; }
        public string Password { get; set; }
    }
}
