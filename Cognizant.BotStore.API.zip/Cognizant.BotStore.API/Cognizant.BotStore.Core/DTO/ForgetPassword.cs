﻿namespace Cognizant.BotStore.Core
{
    public class ForgetPassword
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
