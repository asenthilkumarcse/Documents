﻿namespace Cognizant.BotStore.Core
{
    public class RuleMasterModel
    {
        public int RuleMasterID { get; set; }
        public string RuleName { get; set; }
        public int RuleTypeID { get; set; }
        public int BotMasterID { get; set; }
        public string RuleExpression { get; set; }
        public bool? IsBotStore { get; set; }
        public bool? IsSelected { get; set; }
        public int AccountBotRuleID { get; set; }
    }
}
