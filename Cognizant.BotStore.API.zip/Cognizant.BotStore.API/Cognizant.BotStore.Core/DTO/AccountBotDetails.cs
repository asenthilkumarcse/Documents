﻿namespace Cognizant.BotStore.Core
{
    public class AccountBotDetails
    {
        public int AccountBotID { get; set; }
        public int AccountID { get; set; }
        public int BotMasterID { get; set; }
        public string AccountName { get; set; }
        public string BotName { get; set; }
        public bool IsSelected { get; set; }
        public bool IsRuleEnabled { get; set; }
    }
}
