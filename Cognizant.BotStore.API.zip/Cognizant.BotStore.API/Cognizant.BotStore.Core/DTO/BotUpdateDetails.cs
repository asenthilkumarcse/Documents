﻿using System.Collections.Generic;

namespace Cognizant.BotStore.Core
{
    public class BotUpdateDetails
    {
        public BotMaster BotMaster { get; set; }
        public List<DeleteMaster> DeleteIntendMaster { get; set; }
        public List<DeleteMaster> DeleteAttributeMaster { get; set; }
        public List<DeleteMaster> DeleteSkillMaster { get; set; }
        public List<DeleteMaster> DeleteRuleMaster { get; set; }
        public List<DeleteMaster> DeleteChannel { get; set; }
    }
    public class DeleteMaster
    {
        public int DeleteID { get; set; }
    }
}
