﻿namespace Cognizant.BotStore.Shared
{
    public class DecryptionSetting
    {
        public string DecrtyptionEnviornmentVaribale { get; set; }
        public string EncryptionMarkerStart { get; set; }
        public string EncryptionMarkerEnd { get; set; }
    }
}
