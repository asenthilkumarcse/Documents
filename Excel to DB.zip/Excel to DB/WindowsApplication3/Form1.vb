﻿Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO.Ports
Imports System.IO
Imports System.Xml

Public Class Form1
    Dim dtTS As New DataTable
    Dim dtTable As New DataTable
    Dim DatabaseNames As String
    Dim TableNames As String
    '  Dim gmAll As New GridCheckMarksSelection
    Dim FromColumnsQuery As String
    Dim ToColumnsQuery As String
    Dim ColumnsName As DataTable
    Dim dtFromTable As New DataTable
    Dim dtToTable As New DataTable
    Dim dtFromColumns As New DataTable
    Dim dtToColumns As DataTable
    Dim dtExcel As DataTable
    Dim ExcelConnection As System.Data.OleDb.OleDbConnection
    Dim Dataadapter As OleDbDataAdapter
    Dim dataset As New DataSet
    Dim FromConnectionString As String
    Dim intarray() As String = {"int", "smallint", "bigint", "tinyint", "money", "smallmoney", "decimal", "numeric", "float", "double"}
    Dim datearray() As String = {"datetime", "smalldatetime"}
    Dim chararray() As String = {"char", "varchar", "text", "nvarchar", "nchar"}
    Dim strExcelFile As String
    Dim strFromServer As String
    Dim strFromUsername As String
    Dim strFromPassword As String
    Dim strFromDatabase As String
    Dim strFromTable As String
    Dim strToServer As String
    Dim strToUsername As String
    Dim strToPassword As String
    Dim strToDatabase As String
    Dim strToTable As String
    Dim con As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con = "Data Source= 10.0.0.48;Initial Catalog=BTLIMS_14Jan2015;User ID= sa;Password= bclims@1;"
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Using ExcelFile As New OpenFileDialog
            If ExcelFile.ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox1.Text = ExcelFile.FileName
                'TextBox1.Properties.ReadOnly = True
            End If
        End Using
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        ExcelImport()
    End Sub

    Private Function ExcelImport() As Boolean
        Try

            ExcelConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + TextBox1.Text + ";Extended Properties=Excel 12.0;")
            Dataadapter = New OleDbDataAdapter("Select * From [Sheet1$]", ExcelConnection)
            ExcelConnection.Open()
            dataset = New DataSet
            Dataadapter.Fill(dataset)
            ExcelConnection.Close()
            dtExcel = dataset.Tables(0)
            Dim dv As DataView = New DataView(dtExcel, "Len(Item) > 0", "", DataViewRowState.CurrentRows)
            Dim intloop As Integer
            If Not dv Is Nothing AndAlso dv.Count > 0 Then
                For intloop = 0 To dv.Count - 1
                    Dim params() As SqlParameter = New SqlParameter(7) {}
                    params(0) = New SqlParameter("@QBClientName", IIf(IsDBNull(dv.Item(intloop)("Name")) Or Len(dv.Item(intloop)("Name")) = 0, DBNull.Value, Trim(dv.Item(intloop)("Name"))))
                    params(1) = New SqlParameter("@Item", IIf(IsDBNull(dv.Item(intloop)("Item")) Or Len(dv.Item(intloop)("Item")) = 0, DBNull.Value, Trim(dv.Item(intloop)("Item"))))
                    params(2) = New SqlParameter("@Memo", IIf(IsDBNull(dv.Item(intloop)("Memo")) Or Len(dv.Item(intloop)("Memo")) = 0, DBNull.Value, Trim(dv.Item(intloop)("Memo"))))
                    If Not IsDBNull(dv.Item(intloop)("Qty")) AndAlso Len(dv.Item(intloop)("Qty")) > 0 Then
                        params(3) = New SqlParameter("@Qty", Trim(dv.Item(intloop)("Qty")))
                    Else
                        params(3) = New SqlParameter("@Qty", 1)
                    End If
                    If Not IsDBNull(dv.Item(intloop)("Sales Price")) AndAlso Len(dv.Item(intloop)("Sales Price")) > 0 Then
                        params(4) = New SqlParameter("@SalesPrice", Trim(dv.Item(intloop)("Sales Price")))
                    Else
                        params(4) = New SqlParameter("@SalesPrice", 0)
                    End If
                    If Not IsDBNull(dv.Item(intloop)("Amount")) AndAlso Len(dv.Item(intloop)("Amount")) > 0 Then
                        params(5) = New SqlParameter("@Amount", Trim(dv.Item(intloop)("Amount")))
                    Else
                        params(5) = New SqlParameter("@Amount", 0)
                    End If
                    params(6) = New SqlParameter("@InvoiceDate", IIf(IsDBNull(dv.Item(intloop)("Date")) Or Len(dv.Item(intloop)("Date")) = 0, DBNull.Value, Trim(dv.Item(intloop)("Date"))))
                    params(7) = New SqlParameter("@InvoiceNumber", IIf(IsDBNull(dv.Item(intloop)("Num")) Or Len(dv.Item(intloop)("Num")) = 0, DBNull.Value, Trim(dv.Item(intloop)("Num"))))
                    SqlHelper.ExecuteNonQuery(con, CommandType.StoredProcedure, "QBPricing_Insert_SP", params)
                Next
            End If
            MsgBox("Records Imported Successfully!", MsgBoxStyle.Information)
        Catch ex As Exception
            MsgBox("File Cannot be Imported", MessageBoxIcon.Error)
        End Try
        Return Nothing
    End Function
End Class
